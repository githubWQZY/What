package com.jsyunsi;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;

public class Star {
	public static final int WIDTH = 50;
	public static final int LENGTH = 50;
	private int x,y;
	public boolean have = true;
	private static Toolkit tk = Toolkit.getDefaultToolkit();
	private static Image image = null;
	static{
		image = tk.getImage(Tree.class.getResource("../../Images/star.jpg"));
	}
	public void draw(Graphics g){
		if(have)
			g.drawImage(image, x, y, WIDTH, LENGTH, null);
	}
	public Star() {
		x = (int)(Math.random()*300);
		y = (int)(Math.random()*350)+320;
	}
	public Rectangle getRect() {
		return new Rectangle(x,y,WIDTH,LENGTH);
	}
	
	
}
