package com.jsyunsi;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.util.List;

public class Bullet {
	public static final int WIDTH = 10;
	public static final int LENGTH = 10;
	private int x,y;
	private Direction direction;
	public static int speedX = 10;
	public static int speedY = 10;
	private boolean good;
	private Client c;
	private boolean live = true;
	private static Toolkit tk = Toolkit.getDefaultToolkit();
	private static Image[] images = null;
	static{
		images = new Image[]{
				tk.getImage(Bullet.class.getResource("../../Images/bulletL.gif")),
				tk.getImage(Bullet.class.getResource("../../Images/bulletU.gif")),
				tk.getImage(Bullet.class.getResource("../../Images/bulletR.gif")),
				tk.getImage(Bullet.class.getResource("../../Images/bulletD.gif")),
		};
	}
	public Bullet(int x, int y, Direction direction, boolean good,Client c) {
		super();
		this.x = x;
		this.y = y;
		this.direction = direction;
		this.good = good;
		this.c = c;
	}
	public Rectangle getRect(){
		return new Rectangle(x,y,WIDTH,LENGTH);
	}
	public void draw(Graphics g){
		switch(direction){
		case L:
			g.drawImage(images[0], x, y, WIDTH, LENGTH/2, null);
			break;
		case U:
			g.drawImage(images[1], x, y, WIDTH, LENGTH, null);
			break;
		case R:
			g.drawImage(images[2], x, y, WIDTH, LENGTH/2, null);
			break;
		case D:
			g.drawImage(images[3], x, y, WIDTH, LENGTH, null);
			break;
		default:
			break;
		}
		move();
	}
	private void move() {
		// TODO Auto-generated method stub
		switch(direction){
		case L:
			x -= speedX;
			break;
		case U:
			y -= speedY;
			break;
		case R:
			x += speedX;
			break;
		case D:
			y += speedY;
			break;
		}
		if((x <= 0) || (x + LENGTH > Client.FRAME_WIDTH)){
			this.c.bullets.remove(this);
		}
		if((y <= 0) || (y + LENGTH > Client.FRAME_LENGTH)){
			this.c.bullets.remove(this);
		}
	}
	//�ӵ�������ͨǽ
	public void collideWithCommonWall(CommonWall cw){
		if(this.getRect().intersects(cw.getRect())){
			this.c.bullets.remove(this);
			this.c.otherwall.remove(cw);
		}
	}
	//�ӵ����мҵ�ǽ
	public void collideWithHomeWall(CommonWall cw){
		if(this.getRect().intersects(cw.getRect())){
			this.c.bullets.remove(this);
			this.c.homewall.remove(cw);
		}
	}
	//�ӵ����н���ǽ
	public void collideWithMetalWall(MetalWall cw){
		if(this.getRect().intersects(cw.getRect())){
			if((!this.c.star.have) && (this.good == this.c.homeTank.isGood())){
					this.c.metalwalls.remove(cw);
			}
			this.c.bullets.remove(this);
		}
	}
	//�ӵ��Դ�
	public void collideWithBullets(List<Bullet> bullets){
		for (int i = 0; i < bullets.size(); i++) {
			Bullet b = bullets.get(i);
			if((this.good != b.good) && (this != b) && (this.getRect().intersects(b.getRect()))){
				this.c.bullets.remove(this);
				bullets.remove(b);
			}
		}
	}
	//�ӵ�����̹��
	public void collideWithTank(Tank t){
		if((this.good != t.isGood()) && (this.getRect().intersects(t.getRect()))){
			BombTank bt = new BombTank(t.getX(),t.getY(),this.c);
			this.c.bombTanks.add(bt);
			if(!t.isGood()){
				//�ҷ�̹�˵��ӵ����ез�̹��
				this.c.bullets.remove(this);
				this.c.tanks.remove(t);
			}else{
				//�з�̹�˵��ӵ������ҷ�̹��
				this.c.bullets.remove(this);
				t.setLife(t.getLife() - 50);
				if(t.getLife() <=0 ){
					t.setLive(false);	
				}
			}
		}
	}
	//�ӵ�����Home
	public void collideWithHome(Home home){
		if(this.getRect().intersects(home.getRect())){
			//��Ϸ������GameOver
			BombTank bt = new BombTank(home.getX(),home.getY(),this.c);
			this.c.bombTanks.add(bt);
			home.setLive(false);
			this.c.bullets.remove(this);
			this.c.homeTank.setLive(false);
		}
	}
	
	
}
