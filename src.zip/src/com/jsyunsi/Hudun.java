package com.jsyunsi;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;

public class Hudun {
	public static final int WIDTH = 60;
	public static final int LENGTH = 50;
	private int x,y;
	private boolean have = true;
	private static Toolkit tk = Toolkit.getDefaultToolkit();
	private static Image image = null;
	static{
		image = tk.getImage(Tree.class.getResource("../../Images/hudun.jpg"));
	}
	public void draw(Graphics g){
			g.drawImage(image, x, y, WIDTH, LENGTH, null);
	}
	public Hudun() {
		x = (int)(Math.random()*150)+950;
		y = (int)(Math.random()*450)+300;
	}
	public Rectangle getRect() {
			return new Rectangle(x,y,WIDTH,LENGTH);
	}
	public boolean isHave() {
		return have;
	}
	public void setHave(boolean have) {
		this.have = have;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
}
