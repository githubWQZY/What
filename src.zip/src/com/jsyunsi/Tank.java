package com.jsyunsi;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.util.List;

public class Tank {
	public static final int WIDTH = 40;
	public static final int LENGTH = 40;
	private int x, y;
	private int oldx, oldy;
	private Direction direction;
	private Direction oldDirection = Direction.U;
	private boolean bL, bU, bR, bD = false;
	private boolean good;
	public static int speedX = 6;
	public static int speedY = 6;
	private int life = 200;
	private Client c;
	private boolean live = true;
	private int n = (int)(Math.random()*10)+5;
	private static Toolkit tk = Toolkit.getDefaultToolkit();
	private static Image[] images = null;
	static {
		images = new Image[] { tk.getImage(Tank.class.getResource("../../Images/tankL.gif")),
				tk.getImage(Tank.class.getResource("../../Images/tankU.gif")),
				tk.getImage(Tank.class.getResource("../../Images/tankR.gif")),
				tk.getImage(Tank.class.getResource("../../Images/tankD.gif")) };
	}
	

	public boolean isGood() {
		return good;
	}

	public void setGood(boolean good) {
		this.good = good;
	}
	
	

	public boolean isLive() {
		return live;
	}

	public void setLive(boolean live) {
		this.live = live;
	}

	public int getLife() {
		return life;
	}

	public void setLife(int life) {
		this.life = life;
	}
	
	

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public Tank(int x, int y, Direction direction, boolean good,Client c) {
		super();
		this.x = x;
		this.y = y;
		this.direction = direction;
		this.good = good;
		this.c = c;
	}

	public void draw(Graphics g) {
		
		if(good){
			if(!live){
				//��Ϸ����
				return;
			}
		}
		if(!good){
			if(n == 0){
				Direction[] directions = Direction.values();
				int rn = (int)(Math.random()*4);
				direction = directions[rn];
				n = (int)(Math.random()*10)+5;
			}
			n--;
			if((int)(Math.random()*40)>38)
				fire();
		}
		switch (direction) {
		case L:
			g.drawImage(images[0], x, y, WIDTH, LENGTH, null);
			break;
		case U:
			g.drawImage(images[1], x, y, WIDTH, LENGTH, null);
			break;
		case R:
			g.drawImage(images[2], x, y, WIDTH, LENGTH, null);
			break;
		case D:
			g.drawImage(images[3], x, y, WIDTH, LENGTH, null);
			break;
		case STOP:
			if (oldDirection == Direction.L) {
				g.drawImage(images[0], x, y, WIDTH, LENGTH, null);
				break;
			} else if (oldDirection == Direction.U) {
				g.drawImage(images[1], x, y, WIDTH, LENGTH, null);
				break;
			} else if (oldDirection == Direction.R) {
				g.drawImage(images[2], x, y, WIDTH, LENGTH, null);
				break;
			} else if (oldDirection == Direction.D) {
				g.drawImage(images[3], x, y, WIDTH, LENGTH, null);
				break;
			}
		}
		move();
	}

	private void move() {
		oldx = x;
		oldy = y;
		switch (direction) {
		case L:
			x -= speedX;
			break;
		case U:
			y -= speedY;
			break;
		case R:
			x += speedX;
			break;
		case D:
			y += speedY;
			break;
		case STOP:
			break;
		}
		if (x < 0) {
			x = 0;
		}
		if (y < 60) {
			y = 60;
		}
		if (x + WIDTH > Client.FRAME_WIDTH) {
			x = Client.FRAME_WIDTH - WIDTH;
		}
		if (y + LENGTH > Client.FRAME_LENGTH) {
			y = Client.FRAME_LENGTH - LENGTH;
		}
	}

	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		switch (key) {
		case KeyEvent.VK_A:
			bL = true;
			break;
		case KeyEvent.VK_W:
			bU = true;
			break;
		case KeyEvent.VK_D:
			bR = true;
			break;
		case KeyEvent.VK_S:
			bD = true;
			break;
		}
		decideDirection();
	}

	public void keyReleased(KeyEvent e) {
		int key = e.getKeyCode();
		switch (key) {
		case KeyEvent.VK_A:
			bL = false;
			break;
		case KeyEvent.VK_W:
			bU = false;
			break;
		case KeyEvent.VK_D:
			bR = false;
			break;
		case KeyEvent.VK_S:
			bD = false;
			break;
		case KeyEvent.VK_J:
			if(live){
				fire();
			}
			break;
		}
		decideDirection();
	}

	private void decideDirection() {
		// TODO Auto-generated method stub
		if (bL && !bU && !bR && !bD) {
			direction = Direction.L;
			oldDirection = direction;
		} else if (bU && !bR && !bD && !bL) {
			direction = Direction.U;
			oldDirection = direction;
		} else if (bR && !bD && !bL && !bU) {
			direction = Direction.R;
			oldDirection = direction;
		} else if (bD && !bL && !bU && !bR) {
			direction = Direction.D;
			oldDirection = direction;
		} else if (!bL && !bU && !bR && !bL) {
			direction = Direction.STOP;
		}
	}
	public void fire(){
		int x = this.x + WIDTH/2 - Bullet.WIDTH/2;
		int y = this.y + LENGTH/2 - Bullet.LENGTH/2;
		Direction dir = this.direction;
		if(this.direction == Direction.STOP){
			dir = oldDirection;
		}
		boolean good = this.good;
		this.c.bullets.add(new Bullet(x,y,dir,good,this.c));
	}
	//̹�˸�������ײ
	public void collideWithRiver(River river){
		if(this.getRect().intersects(river.getRect())){
			changeXY();
		}
	}
	//̹�˸�����ǽ��ײ
	public void collideWithMetalWall(MetalWall mw){
		if(this.getRect().intersects(mw.getRect())){
			changeXY();
		}
	}
	//̹�˸���ͨǽ��ײ
	public void collideWithCommonWall(CommonWall cw){
		if(this.getRect().intersects(cw.getRect())){
			changeXY();
		}
	}
	//̹�˸�����ײ
	public void collideWithHome(Home home){
		if(this.getRect().intersects(home.getRect())){
			changeXY();
		}
	}
	//̹�˸�̹����ײ
	public void collideWithTank(List<Tank> tanks){
		for (int i = 0; i < tanks.size(); i++) {
			Tank t = tanks.get(i);
			if((this != t) && (this.getRect().intersects(t.getRect()))){
				this.changeXY();
				t.changeXY();
			}
		}
	}
	//̹�˸�������ײ
	public void collideWithStar(Star star){
		if(this.getRect().intersects(star.getRect())){
			this.c.star.have = false;
		}
	}
	//̹�˸�������ײ
	public void collideWithHudun(Hudun hudun){
		if(this.getRect().intersects(hudun.getRect())){
			this.c.hudun.setX(-100);
			this.c.hudun.setY(-100);
			this.c.hudun.setHave(false);
		}
	}
	
	
	private void changeXY(){
		x = oldx;
		y = oldy;
	}
	
	public Rectangle getRect(){
		return new Rectangle(x,y,WIDTH,LENGTH);
	}
}