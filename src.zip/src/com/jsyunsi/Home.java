package com.jsyunsi;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;

public class Home {
	public static final int WIDTH = 50;
	public static final int LENGTH = 50;
	private int x,y;
	private boolean live = true;
	private static Toolkit tk = Toolkit.getDefaultToolkit();
	private static Image image = null;
	static{
		image = tk.getImage(Tree.class.getResource("../../Images/home.jpg"));
	}
	public void draw(Graphics g){
		if(!live){
			return;
		}
		g.drawImage(image, x, y, WIDTH, LENGTH, null);
	}
	public Home(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return new Rectangle(x,y,WIDTH,LENGTH);
	}
	public boolean isLive() {
		return live;
	}
	public void setLive(boolean live) {
		this.live = live;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	
}
