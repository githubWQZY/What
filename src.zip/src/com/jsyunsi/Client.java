package com.jsyunsi;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JOptionPane;

public class Client extends Frame implements ActionListener {

	/**
	 * ̹�˴�ս����
	 */
	private static final long serialVersionUID = 1L;
	// �����Ŀ��Ⱥ͸߶�
	public static final int FRAME_WIDTH = 1200;
	public static final int FRAME_LENGTH = 800;
	// ��ȡ��Ļ�ĳߴ�
	Toolkit tk = Toolkit.getDefaultToolkit();
	Dimension screenSize = tk.getScreenSize();
	int screenWidth = screenSize.width;
	int screenLength = screenSize.height;
	// ������Ϸ�˵�(�˵���̨���˵����˵��µ�ѡ��)
	MenuBar jmb = null;
	Menu jm1, jm2, jm3, jm4 = null;
	MenuItem jmi1, jmi2, jmi3, jmi4, jmi5, jmi6, jmi7, jmi8, jmi9 = null;
	private boolean printable = true;

	// ���廭��
	Image screenImage = null;
	// ����River
	River river = null;
	// ����Tree����
	List<Tree> trees = new ArrayList<Tree>();
	// ����MatelWall����
	List<MetalWall> metalwalls = new ArrayList<MetalWall>();
	List<MetalWall> metalwalls1 = new ArrayList<MetalWall>();
	// ����otherWall����
	List<CommonWall> otherwall = new ArrayList<CommonWall>();
	// ����ҵ�ǽ
	List<CommonWall> homewall = new ArrayList<CommonWall>();
	// ����home
	Home home = null;
	// �����ҷ�̹��
	Tank homeTank = null;
	// ����з�̹�˼���
	List<Tank> tanks = new ArrayList<Tank>();
	// �����ӵ�����
	List<Bullet> bullets = new ArrayList<Bullet>();
	// ���屬ը̹�˵ļ���
	List<BombTank> bombTanks = new ArrayList<BombTank>();
	// ��������
	Star star = null;
	// ���廤��
	Hudun hudun = null;
	private boolean flag = true;

	// ������
	public static void main(String[] args) {
		new Client();
	}

	//
	public void update(Graphics g) {
		// �õ�����
		screenImage = this.createImage(FRAME_WIDTH, FRAME_LENGTH);
		// ��û����Ļ��ʲ����Ʒ�װ����
		Graphics gps = screenImage.getGraphics();
		framePaint(gps);
		// ÿ�ν���������Frame�򣬴ﵽˢ��Ч��
		g.drawImage(screenImage, 0, 0, null);
	}

	private void framePaint(Graphics g) {
		// ̹�˳Զ��Ƶ���ʵ�ּ�ǽת����ǽ
		if (!hudun.isHave()) {
			homewall.clear();
			for (int i = 0; i < 4; i++) {
				metalwalls1.add(new MetalWall(550, 725 + i * 25));
				metalwalls1.add(new MetalWall(625, 725 + i * 25));
				metalwalls1.add(new MetalWall(550 + i * 25, 700));
			}

			for (int i = 0; i < metalwalls1.size(); i++) {
				metalwalls1.get(i).draw(g);
			}
			Timer timer = new Timer();
			timer.schedule(new TimerTask() {
				public void run() {
					if (flag) {
						{
							metalwalls1.clear();
							hudun.setHave(true);
							// firstsethome2();
							for (int i = 0; i < 4; i++) {
								homewall.add(new CommonWall(550, 725 + i * 25));
								homewall.add(new CommonWall(625, 725 + i * 25));
								homewall.add(new CommonWall(550 + i * 25, 700));
							}
							for (int i = 0; i < homewall.size(); i++) {
								homewall.get(i).draw(g);
							}
							flag = false;
						}
					}
				}
			}, 1000 * 30);
		}
		// �ж���Ϸ��Ӯ
		// 1.Ӯ
		if (homeTank.isLive() && home.isLive() && tanks.size() == 0) {
			// Ӯ��,���ҳ������ӵ�������ש�飬������ʾ�û�����
			this.bullets.clear();
			this.otherwall.clear();
			g.setColor(Color.RED);
			g.setFont(new Font("TimesRoman", Font.BOLD, 70));
			g.drawString("��ϲ�����", 450, 350);
		}
		// 2.��
		if (!homeTank.isLive() || !home.isLive()) {
			this.otherwall.clear();
			g.setColor(Color.RED);
			g.setFont(new Font("TimesRoman", Font.BOLD, 70));
			g.drawString("Game Over", 450, 350);
			printable = false;
		}
		// ���ƻ���
		hudun.draw(g);
		// ��������
		star.draw(g);
		// ����ʣ��з�̹�˵������Լ��ҷ�̹�˵�����ֵ
		g.setColor(Color.GREEN);
		g.setFont(new Font("TimesRoman", Font.BOLD, 30));
		g.drawString("ʣ��з�̹�ˣ�" + tanks.size(), 200, 100);
		g.drawString("����ֵ��" + homeTank.getLife(), 600, 100);
		// ���Ʊ�ը
		for (int i = 0; i < bombTanks.size(); i++) {
			bombTanks.get(i).draw(g);
		}
		// �����ӵ�
		for (int i = 0; i < bullets.size(); i++) {
			Bullet b = bullets.get(i);
			b.draw(g);
			b.collideWithTank(homeTank);
			b.collideWithBullets(bullets);
			b.collideWithHome(home);
			for (int j = 0; j < otherwall.size(); j++) {
				b.collideWithCommonWall(otherwall.get(j));
			}
			for (int j = 0; j < homewall.size(); j++) {
				b.collideWithHomeWall(homewall.get(j));
			}
			// ����
			for (int j = 0; j < metalwalls.size(); j++) {
				b.collideWithMetalWall(metalwalls.get(j));
			}
			for (int j = 0; j < metalwalls1.size(); j++) {
				b.collideWithMetalWall(metalwalls1.get(j));
			}
			// ���ô�з�̹�˵ķ���
			for (int j = 0; j < tanks.size(); j++) {
				b.collideWithTank(tanks.get(j));
			}
		}
		// ���ƺ���
		river.draw(g);
		homeTank.collideWithRiver(river);
		// ���ƽ���ǽ
		for (int i = 0; i < metalwalls.size(); i++) {
			metalwalls.get(i).draw(g);
			homeTank.collideWithMetalWall(metalwalls.get(i));
		}
		for (int i = 0; i < metalwalls1.size(); i++) {
			homeTank.collideWithMetalWall(metalwalls1.get(i));
		}

		// ������ͨǽ
		for (int i = 0; i < otherwall.size(); i++) {
			otherwall.get(i).draw(g);
			homeTank.collideWithCommonWall(otherwall.get(i));
		}
		// ���Ƽҵ�ǽ
		for (int i = 0; i < homewall.size(); i++) {
			homewall.get(i).draw(g);
			homeTank.collideWithCommonWall(homewall.get(i));
		}
		// ���Ƽ�
		home.draw(g);
		homeTank.collideWithHome(home);
		// �����ҷ�̹��
		homeTank.draw(g);
		homeTank.collideWithTank(tanks);
		homeTank.collideWithStar(star);
		homeTank.collideWithHudun(hudun);

		// ���Ƶз�̹��
		for (int i = 0; i < tanks.size(); i++) {
			Tank t = tanks.get(i);
			t.draw(g);
			t.collideWithRiver(river);
			t.collideWithHome(home);
			t.collideWithTank(tanks);
			for (int j = 0; j < otherwall.size(); j++) {
				t.collideWithCommonWall(otherwall.get(j));
			}
			for (int j = 0; j < homewall.size(); j++) {
				t.collideWithCommonWall(homewall.get(j));
			}
			for (int j = 0; j < metalwalls.size(); j++) {
				t.collideWithMetalWall(metalwalls.get(j));
			}
		}
		// ������
		for (int i = 0; i < trees.size(); i++) {
			trees.get(i).draw(g);
		}
	}

	public Client() {
		// ��ʼ������
		hudun = new Hudun();

		// ��ʼ������
		star = new Star();
		// ��ʼ���з�20��̹��
		for (int i = 0; i < 20; i++) {
			if (i < 9) {
				tanks.add(new Tank(200 + i * 65, 100, Direction.D, false, this));
			} else if (i < 14) {
				tanks.add(new Tank(0, 150 + (i - 9) * 65, Direction.D, false, this));
			} else {
				tanks.add(new Tank(1100, 400 + (i - 14) * 65, Direction.D, false, this));
			}
		}
		// ��ʼ���ҷ�̹��
		homeTank = new Tank(450, 750, Direction.STOP, true, this);
		// ��ʼ����
		home = new Home(575, 735);
		// ��ʼ��������ͨǽ
		for (int i = 0; i < 18; i++) {
			otherwall.add(new CommonWall(325, 522 + i * 25));
			otherwall.add(new CommonWall(350, 522 + i * 25));
			otherwall.add(new CommonWall(800, 522 + i * 25));
			otherwall.add(new CommonWall(825, 522 + i * 25));
			otherwall.add(new CommonWall(360 + i * 25, 400));
			otherwall.add(new CommonWall(360 + i * 25, 425));
			otherwall.add(new CommonWall(750 + i * 25, 230));
			otherwall.add(new CommonWall(775 + i * 25, 280));

		}
		// ��ʼ���ҵ���ͨǽ
		for (int i = 0; i < 4; i++) {
			homewall.add(new CommonWall(550, 725 + i * 25));
			homewall.add(new CommonWall(625, 725 + i * 25));
			homewall.add(new CommonWall(550 + i * 25, 700));
		}
		// ��ʼ������ǽ
		for (int i = 0; i < 10; i++) {
			metalwalls.add(new MetalWall(160 + i * 40, 200));
			metalwalls.add(new MetalWall(160 + i * 40, 230));
		}
		for (int i = 0; i < 7; i++) {
			metalwalls.add(new MetalWall(920, 520 + i * 40));
		}
		// ��ʼ��Tree
		for (int i = 0; i < 4; i++) {
			trees.add(new Tree(0 + i * 40, 480));
			trees.add(new Tree(350 + i * 40, 480));
			trees.add(new Tree(700 + i * 40, 480));
			trees.add(new Tree(1035 + i * 40, 480));
		}

		// ��ʼ��River
		river = new River(100, 150);
		// ��ʼ����Ϸ�˵�
		jmb = new MenuBar();
		jm1 = new Menu("��Ϸ");
		jm2 = new Menu("��ͣ/����");
		jm3 = new Menu("��Ϸ����");
		jm4 = new Menu("����");
		jmi1 = new MenuItem("��ʼ����Ϸ");
		jmi2 = new MenuItem("�˳�");
		jmi3 = new MenuItem("��ͣ");
		jmi4 = new MenuItem("����");
		jmi5 = new MenuItem("��Ϸ����1");
		jmi6 = new MenuItem("��Ϸ����2");
		jmi7 = new MenuItem("��Ϸ����3");
		jmi8 = new MenuItem("��Ϸ����4");
		jmi9 = new MenuItem("��Ϸ˵��");
		jm1.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jm2.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jm3.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jm4.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jmi1.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jmi2.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jmi3.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jmi4.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jmi5.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jmi6.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jmi7.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jmi8.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jmi9.setFont(new Font("TimesRoman", Font.BOLD, 15));
		jmi1.addActionListener(this);
		jmi1.setActionCommand("Begin");
		jmi2.addActionListener(this);
		jmi2.setActionCommand("Exit");
		jmi3.addActionListener(this);
		jmi3.setActionCommand("Stop");
		jmi4.addActionListener(this);
		jmi4.setActionCommand("Continue");
		jmi5.addActionListener(this);
		jmi5.setActionCommand("Level1");
		jmi6.addActionListener(this);
		jmi6.setActionCommand("Level2");
		jmi7.addActionListener(this);
		jmi7.setActionCommand("Level3");
		jmi8.addActionListener(this);
		jmi8.setActionCommand("Level4");
		jmi9.addActionListener(this);
		jmi9.setActionCommand("Help");
		jmb.add(jm1);
		jmb.add(jm2);
		jmb.add(jm3);
		jmb.add(jm4);
		jm1.add(jmi1);
		jm1.add(jmi2);
		jm2.add(jmi3);
		jm2.add(jmi4);
		jm3.add(jmi5);
		jm3.add(jmi6);
		jm3.add(jmi7);
		jm3.add(jmi8);
		jm4.add(jmi9);
		// �Ѱ�̨���õ�Frame��
		this.setMenuBar(jmb);
		// ���ô��ڿɼ�
		this.setVisible(true);
		// ���ô��ڴ�С���ɱ�
		this.setResizable(false);
		// ���ô��ڳߴ�
		this.setSize(FRAME_WIDTH, FRAME_LENGTH);
		// ���ô���λ��Ϊ��Ļ����
		this.setLocation(screenWidth / 2 - FRAME_WIDTH / 2, screenLength / 2 - FRAME_LENGTH / 2);
		// ���ñ�����ɫ
		this.setBackground(Color.darkGray);
		// ���ñ���
		this.setTitle("̹�˴�ս");
		// ���ô��ڹر�ģʽ
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		// ���Ӽ��̼����¼�
		this.addKeyListener(new KeyMonitor());
		// �����߳�
		new Thread(new PaintThread()).start();

	}

	private class PaintThread implements Runnable {
		public void run() {
			while (printable) {
				repaint();
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	

	public void actionPerformed(ActionEvent e) {

		if (e.getActionCommand().equals("Begin")) {
			System.out.println("Begin");
			printable = false;
			Object[] options = { "ȷ��", "ȡ��" };
			int response = JOptionPane.showOptionDialog(this, "��ȷ��Ҫ���¿�ʼ��", "", JOptionPane.YES_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
			if (response == 0) {
				new Client();
			} else {
				printable = true;
				new Thread(new PaintThread()).start();
			}
		} else if (e.getActionCommand().equals("Exit")) {
			System.out.println("Exit");
			printable = false;
			Object[] options = { "ȷ��", "ȡ��" };
			int response = JOptionPane.showOptionDialog(this, "��ȷ��Ҫ�˳���", "", JOptionPane.YES_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
			if (response == 0) {
				System.exit(0);
			} else {
				printable = true;
				new Thread(new PaintThread()).start();
			}
		} else if (e.getActionCommand().equals("Stop")) {
			System.out.println("Stop");
			printable = false;
		} else if (e.getActionCommand().equals("Continue")) {
			System.out.println("Contiue");
			if (!printable) {
				printable = true;
				new Thread(new PaintThread()).start();
			}
		} else if (e.getActionCommand().equals("Level1")) {
			System.out.println("Level1");
			Tank.speedX = 6;
			Tank.speedY = 6;
			Bullet.speedX = 10;
			Bullet.speedY = 10;
		} else if (e.getActionCommand().equals("Level2")) {
			System.out.println("Level2");
			Tank.speedX = 8;
			Tank.speedY = 8;
			Bullet.speedX = 12;
			Bullet.speedY = 12;
		} else if (e.getActionCommand().equals("Level3")) {
			System.out.println("Level3");
			Tank.speedX = 10;
			Tank.speedY = 10;
			Bullet.speedX = 14;
			Bullet.speedY = 14;
		} else if (e.getActionCommand().equals("Level4")) {
			System.out.println("Level4");
			Tank.speedX = 12;
			Tank.speedY = 12;
			Bullet.speedX = 16;
			Bullet.speedY = 16;
		} else if (e.getActionCommand().equals("Help")) {
			System.out.println("Help");
			printable = false;
			JOptionPane.showMessageDialog(null, "��A��W��S��D���Ʒ�����J�����ӵ�����R���¿�ʼ��Ϸ", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
			printable = true;
			new Thread(new PaintThread()).start();
		}
	}

	private class KeyMonitor extends KeyAdapter {
		public void keyPressed(KeyEvent e) {
			homeTank.keyPressed(e);
		}

		public void keyReleased(KeyEvent e) {
			homeTank.keyReleased(e);
		}
	}
}
