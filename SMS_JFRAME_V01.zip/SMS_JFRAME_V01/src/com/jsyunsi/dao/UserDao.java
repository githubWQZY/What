package com.jsyunsi.dao;

import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jsyunsi.entity.User;
import com.jsyunsi.util.DBUtil;
import com.jsyunsi.view.Login;

public class UserDao {
	//��¼��֤
	public User checkLogin(String userName,String passWord){

		User user = null;
		//1.�������
		Connection conn = DBUtil.getConn();
		//2.��дsql
		String sql = "select * from user";
		//3.���sqlִ������������������
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				//System.out.println(rs.getString(1)+rs.getString(2));
				if(rs.getString(1).equals(userName) && rs.getString(2).equals(passWord)){
					user = new User(userName,passWord);
					//System.out.println(rs.getString(1)+rs.getString(2));
					break;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.close(rs, ps, conn);
		}
		return user;
	}
	//�����û�����ѯ����
	public String getPassWordByUserName(String userName){
		String passWord = "";
		Connection conn = DBUtil.getConn();
		String sql = "select password from user where userName = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, userName);
			rs = ps.executeQuery();
			while(rs.next()){
				passWord = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.close(rs, ps, conn);
		}
		return passWord;
	}
	//�޸�����
	public int updatePassWord(String passWord){
		int count = 0;
		String userName = Login.userName;
		Connection conn = DBUtil.getConn();
		String sql = "update user set password = ? where userName = ?";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, passWord);
			ps.setString(2, userName);
			count = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.close(null, ps, conn);
		}
		return count;
	}
}
