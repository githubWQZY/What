package com.jsyunsi.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jsyunsi.entity.Student;
import com.jsyunsi.util.DBUtil;

public class StudentDao {
	//����ѧ��id��ѯѧ����Ϣ
	public int querySid(String sId){
		int count = 0;
		Connection conn = DBUtil.getConn();
		String sql = "select * from student where sid = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, sId);
			rs = ps.executeQuery();
			while(rs.next()){
				count++;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.close(rs, ps, conn);
		}
		return count;
	}
	//����ѧ����Ϣ
	public int addStudent(Student student){
		int count = 0;
		Connection conn = DBUtil.getConn();
		String sql = "insert into student values(?,?,?,?,?,?,?)";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, student.getsId());
			ps.setString(2, student.getsName());
			ps.setString(3, student.getsSex());
			ps.setString(4, student.getsBirthday());
			ps.setString(5, student.getsProvince());
			ps.setString(6, student.getsHobby());
			ps.setString(7, student.getsPhone());
			count = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.close(null, ps, conn);
		}
		return count;
	}
	public List<Student> queryByCondition(String[] data){
		 List<Student> list = new ArrayList<Student>();
		 //1.�������
		 Connection conn = DBUtil.getConn();
		 //2.��дsql
		 String sql = "select * from student where 1=1";
		 if(!data[0].equals("")){
			 sql += " and sid = '" + data[0] + "' ";
		 }
		 if(!data[1].equals("")){
			 sql += " and sname = '" + data[1] + "' ";
		 }
		 if(!data[2].equals("")){
			 sql += " and sprovince = '" + data[2] + "' ";
		 }
		 if(!data[3].equals("")){
			 sql += " and ssex = '" + data[3] + "' ";
		 }
		 //System.out.println(sql);
		 //���sqlִ������������������
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		 try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			//�����������ȡ������
			while(rs.next()){
				String sId = rs.getString(1);
				String sName = rs.getString(2);
				String sSex = rs.getString(3);
				String sBirthday = rs.getString(4);
				String sProvince = rs.getString(5);
				String sHobby = rs.getString(6);
				String sPhone = rs.getString(7);
				Student student = new Student(sId,sName,sSex,sBirthday,sProvince,sHobby,sPhone);
				list.add(student);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.close(rs, ps, conn);
		}
		 return list;
	}

	//ɾ����Ϣ
	public int deleteStudent(String sId){
		int count = 0;
		Connection conn = DBUtil.getConn();
		String sql = "delete from student where sid = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, sId);
			count = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.close(rs, ps, conn);
		}
		return count;
	}
}
