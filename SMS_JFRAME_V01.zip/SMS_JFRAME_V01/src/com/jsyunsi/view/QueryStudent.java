package com.jsyunsi.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import com.jsyunsi.dao.StudentDao;
import com.jsyunsi.entity.Student;

public class QueryStudent extends JFrame implements ActionListener{
	private JLabel sId,sName,sProvince,sSex;
	private JTextField sIdText,sNameText,sProvinceText,sSexText;
	private JButton query,first,previous,next,last,modify,delete,exportExcel,back;
	private JLabel label1,label2;
	private JTable table;
	private JScrollPane panel;
	private JComboBox box;
	String[] array = {"5","10","15","20"};
	private String[] columnNames = {"ѧ��","����","�Ա�","����","ʡ��","��Ȥ","�绰"};
	private DefaultTableModel model = null;
	private int currentPage = 1;//��ǰҳ
	private int totalPage;//��ҳ��
	private int totalCount;//������
	private int column;//ÿһ�е�����
	private int pageCount;//ÿһҳ��ʾ������
	List<Student> list = new ArrayList<Student>();
	
	public static void main(String[] args) {
		new QueryStudent();
	}
	public QueryStudent(){
		this.setTitle("ѧ����Ϣ��ѯͳ��");
		this.setSize(1040, 680);
		this.setIconImage(Toolkit.getDefaultToolkit().getImage("src/com/jsyunsi/images/logo.jpg"));
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		this.setResizable(false);
		Font font = new Font("����",Font.BOLD,12);
		sId = new JLabel("ѧ��:");
		sId.setFont(font);
		sId.setBounds(100, 30, 40, 30);
		sIdText = new JTextField();
		sIdText.setBounds(145, 30, 100, 30);
		this.add(sId);
		this.add(sIdText); 
		
		sName = new JLabel("ѧ������:");
		sName.setFont(font);
		sName.setBounds(270, 30, 70, 30);
		sNameText = new JTextField();
		sNameText.setBounds(340, 30, 100, 30);
		this.add(sName);
		this.add(sNameText);
		
		sProvince = new JLabel("ʡ��:");
		sProvince.setFont(font);
		sProvince.setBounds(100, 65, 40, 30);
		sProvinceText = new JTextField();
		sProvinceText.setBounds(145, 65, 100, 30);
		this.add(sProvince);
		this.add(sProvinceText);
		
		sSex = new JLabel("ѧ���Ա�:");
		sSex.setFont(font);
		sSex.setBounds(270, 65, 70, 30);
		sSexText = new JTextField();
		sSexText.setBounds(340, 65, 100, 30);
		this.add(sSex);
		this.add(sSexText);
		
		query = new JButton("��ѯ");
		query.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
		query.setBounds(500, 30, 95, 30);
		query.setForeground(Color.blue);
		query.setIcon(new ImageIcon("src/com/jsyunsi/images/query2.png"));
		query.addActionListener(this);
		this.add(query);
		
		first = new JButton("��һҳ");
		first.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		first.setBounds(45, 570, 90, 30);
		first.addActionListener(this);
		this.add(first);
		
		previous = new JButton("��һҳ");
		previous.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		previous.setBounds(165, 570, 90, 30);
		previous.addActionListener(this);
		this.add(previous);
		
		next = new JButton("��һҳ");
		next.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		next.setBounds(285, 570, 90, 30);
		next.addActionListener(this);
		this.add(next);
		
		last = new JButton("���һҳ");
		last.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		last.setBounds(400,570,90,30);
		last.addActionListener(this);
		this.add(last);
		
		modify = new JButton("�޸�");
		modify.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		modify.setBounds(520, 570, 90, 30);
		modify.addActionListener(this);
		this.add(modify);
		
		delete = new JButton("ɾ��");
		delete.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		delete.setBounds(645, 570, 90, 30);
		delete.addActionListener(this);
		this.add(delete);
		
		exportExcel = new JButton("������Excel");
		exportExcel.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		exportExcel.setBounds(765, 570, 120, 30);
		exportExcel.addActionListener(this);
		this.add(exportExcel);
		
		back = new JButton("����");
		back.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		back.setBounds(905, 570, 90, 30);
		back.addActionListener(this);
		this.add(back);
		
		label1 = new JLabel("ÿҳ��ʾ����:");
		label1.setBounds(800, 90, 120, 50);
		this.add(label1);
		
		label2 = new JLabel();
		label2.setBounds(420, 400, 180, 60);
		this.add(label2);
		
		box = new JComboBox(array);
		box.setBounds(890, 105, 100, 20);
		box.addActionListener(this);
		this.add(box);
		
		table = new JTable();
		panel = new JScrollPane();
		panel.setViewportView(table);
		panel.setBounds(40, 135, 950, 420);
		this.add(panel);
		
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == query){
			initTable();
		}else if(e.getSource() == first){
			currentPage = 1;
			initTable();
		}else if(e.getSource() == previous){
			currentPage--;
			if(currentPage < 1){
				currentPage = 1;
			}
			initTable();
		}else if(e.getSource() == next){
			if(currentPage != totalPage){
				currentPage++;
				initTable();
			}
		}else if(e.getSource() == last){
			currentPage = totalPage;
			initTable();
		}else if(e.getSource() == back){
			this.dispose();
		}else if(e.getSource() == box){
			currentPage = 1;
			initTable();
		}else if(e.getSource() == modify){
			int selectedRowIndex = table.getSelectedRow();
			if(selectedRowIndex == -1){
				JOptionPane.showMessageDialog(null, "���ڱ�����ѡ��һ������", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
			}else{
				String sId = table.getValueAt(selectedRowIndex, 0).toString();
				String sName = table.getValueAt(selectedRowIndex, 1).toString();
				String sSex  = table.getValueAt(selectedRowIndex, 2).toString();
				String sBirthday = table.getValueAt(selectedRowIndex, 3).toString();
				String sProvince = table.getValueAt(selectedRowIndex, 4).toString();
				String sHobby = table.getValueAt(selectedRowIndex, 5).toString();
				String sPhone = table.getValueAt(selectedRowIndex, 6).toString();
				Student student = new Student(sId,sName,sSex,sBirthday,sProvince,sHobby,sPhone);
				//����һ���޸ĸ�ѧ����Ϣ�ĵ�����ѧ���ûҲ������޸�
				new ModifyStudent(student);
			}
		}
		else if(e.getSource() == delete){
			int selectedRowIndex = table.getSelectedRow();
			if(selectedRowIndex == -1){
				JOptionPane.showMessageDialog(null, "���ڱ�����ѡ��һ������", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
			}else {
				int result = JOptionPane.showConfirmDialog(null, "ȷ��ɾ��?", "ȷ��", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
				if(result == JOptionPane.OK_OPTION) {
					String sId = table.getValueAt(selectedRowIndex, 0).toString();
					int returnValue = new StudentDao().deleteStudent(sId);
					if(returnValue == 1){
						JOptionPane.showMessageDialog(null,"ɾ���ɹ�");
						initTable();
					}

				}

			}
		}
		else if(e.getSource() == exportExcel){
			new OutputExcel();
		}
	}
	private void initTable() {
		StudentDao dao = new StudentDao();
		String[] data = new String[4];
		data[0] = sIdText.getText();
		data[1] = sNameText.getText();
		data[2] = sProvinceText.getText();
		data[3] = sSexText.getText();
		list = dao.queryByCondition(data);
		if(list.size() == 0){
			JOptionPane.showMessageDialog(null,
					"��������û�в鵽��Ӧ��ѧ����Ϣ", "��Ϣ��ʾ", JOptionPane.INFORMATION_MESSAGE);
		}
		String[][] currentData;
		if(list.size() > 0){
			String str = (String) box.getSelectedItem();
			pageCount = Integer.parseInt(str);
			column = columnNames.length;
			totalCount = list.size();
			totalPage = totalCount%pageCount == 0 ? totalCount/pageCount : totalCount/pageCount + 1;
			label2.setText("�ܹ�" + totalCount + "������|��ǰ��" + currentPage + "ҳ");
			//��ȡÿһҳ������
			//�����ǰҳС����ҳ������ôÿһҳ�����ݾ��ǹ涨��pageCount;
			if(currentPage < totalPage){
				List<Student> pageData = new ArrayList<Student>();
				for (int i = pageCount*(currentPage - 1); i < pageCount*currentPage; i++) {
					pageData.add(list.get(i));
				}
				currentData = new String[pageCount][column];
				for (int i = 0; i < currentData.length; i++) {
					Student student = pageData.get(i);
					String[] a = {student.getsId(),student.getsName(),student.getsSex(),student.getsBirthday(),student.getsProvince(),student.getsHobby(),student.getsPhone()};
					currentData[i] = a;
				}
			}else{
				//��ǰҳ������ҳ����Ҳ�������һҳ
				List<Student> pageData = new ArrayList<Student>();
				for (int i = pageCount*(currentPage-1); i < totalCount; i++) {
					pageData.add(list.get(i));
				}
				currentData = new String[pageData.size()][column];
				for (int i = 0; i < currentData.length; i++) {
					Student student = pageData.get(i);
					String[] a = {student.getsId(),student.getsName(),student.getsSex(),student.getsBirthday(),student.getsProvince(),student.getsHobby(),student.getsPhone()};
					currentData[i] = a;
				}
			}
		}else{
			//û�в�ѯ������
			currentData = new String[20][];
		}
		model = new DefaultTableModel(currentData,columnNames);
		table.setModel(model);
		table.setRowHeight(20);
		//���ñ��������־���
		DefaultTableCellRenderer r = new DefaultTableCellRenderer();
		r.setHorizontalAlignment(JLabel.CENTER);
		table.setDefaultRenderer(Object.class, r);
	}

}
