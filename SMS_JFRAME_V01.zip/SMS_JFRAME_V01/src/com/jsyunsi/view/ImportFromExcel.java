package com.jsyunsi.view;


import com.jsyunsi.dao.StudentDao;
import com.jsyunsi.entity.Student;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;
import java.util.regex.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;



public class ImportFromExcel extends JFrame implements ActionListener {

    private static POIFSFileSystem fs;

    private static HSSFWorkbook wb;//execl

    private static HSSFRow row;//

    private static HSSFSheet sheet;

    private JLabel label;
    private JButton button;
    private JTextField filePathText;
    public static void main(String[] args) {
        new OutputExcel();
    }
    public ImportFromExcel(){
        this.setTitle("Import From Excel");
        this.setSize(900, 500);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        this.setLayout(null);
        Font font = new Font("楷体",Font.BOLD,20);
        label = new JLabel("File: ");
        label.setFont(font);
        label.setBounds(150, 105, 300, 60);
        this.add(label);

        filePathText = new JTextField();
        filePathText.setFont(font);
        filePathText.setBounds(300, 120, 300, 30);
        this.add(filePathText);

        button = new JButton("Import From Excel");
        button.setBounds(350, 300, 200, 30);
        button.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
        button.addActionListener(this);
        this.add(button);

        this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if(e.getSource() == button){
            //System.out.println("anlebutton");
            String filePath = filePathText.getText();
            //System.out.println(filePath);
            InputStream in= null;
            try {
                in = new FileInputStream(filePath);
                boolean flag = readXlsx(in);
                if( flag== true) {
                    JOptionPane.showMessageDialog(null, "Import success,please go to check", "Message:", JOptionPane.INFORMATION_MESSAGE);
                    this.dispose();
                }else{
                    JOptionPane.showMessageDialog(null, "Import failed,please go to check", "Message:", JOptionPane.INFORMATION_MESSAGE);
                    this.dispose();
                    return;
                }
            } catch (FileNotFoundException e1) {
                e1.printStackTrace();
            }
        }
    }

    public static boolean readXlsx(InputStream in){
        List<Student> list = new ArrayList<>();
        String value = null;
        String Sid;
        try {
            fs = new POIFSFileSystem(in);
            wb = new HSSFWorkbook(fs);
            sheet=wb.getSheetAt(0);
            int rowend=sheet.getLastRowNum();
            //System.out.println(rowend+"aaaaaa");
            for (int i = 1; i <=rowend;i++) {
                row=sheet.getRow(i);
                Student s = new Student();
                row.getCell(0).setCellType(Cell.CELL_TYPE_STRING);
                Sid = row.getCell(0).getStringCellValue();
                for(int j = 0; j<7;j++){
                    if( row.getCell(j) != null){
                        row.getCell(j).setCellType(Cell.CELL_TYPE_STRING);
                         value = row.getCell(j).getStringCellValue();
                        switch (j) {
                            case 0:
                                s.setsId(value);
                                break;
                            case 1:
                                s.setsName(value);
                                break;
                            case 2:
                                s.setsSex(value);
                                break;
                            case 3 :
                                s.setsBirthday(value);
                                break;
                            case 4 :
                                s.setsProvince(value);
                                break;
                            case 5 :
                                s.setsHobby(value);
                                break;
                            case 6 :
                                s.setsPhone(value);
                                break;
                        }
                    }
                }

                //System.out.println(s);
                StudentDao dao = new StudentDao();
                int count = dao.querySid(Sid);
                //System.out.println(Sid.equals("") || !isNumber(Sid) || Sid.length() != 10 || count != 0);
                if(Sid.equals("") || !isNumber(Sid) || Sid.length() != 10 || count != 0){
                    JOptionPane.showMessageDialog(null, Sid+"   Sid has been existed,please check.", "Message:", JOptionPane.WARNING_MESSAGE);
                    return false;
                }else {
                    dao.addStudent(s);
                }

            }

        }catch (Exception e) {

            e.printStackTrace();

        }
        return true;
    }
    public static boolean isNumber(String str){
        for (int i = 0; i < str.length(); i++) {
            int chr = str.charAt(i);
            if(chr < 48 || chr > 57){
                return false;
            }
        }
        return true;
    }


}
