package com.jsyunsi.view;


import com.jsyunsi.dao.StudentDao;
import com.jsyunsi.entity.Student;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class ImportFromTxt extends JFrame implements ActionListener {

    private JLabel label;
    private JButton button;
    private JTextField filePathText;
    public static void main(String[] args) {
        new OutputExcel();
    }
    public ImportFromTxt(){
        this.setTitle("Import From Txt");
        this.setSize(900, 500);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        this.setLayout(null);
        Font font = new Font("楷体",Font.BOLD,20);
        label = new JLabel("File: ");
        label.setFont(font);
        label.setBounds(150, 105, 300, 60);
        this.add(label);

        filePathText = new JTextField();
        filePathText.setFont(font);
        filePathText.setBounds(300, 120, 300, 30);
        this.add(filePathText);

        button = new JButton("Import From Txt");
        button.setBounds(350, 300, 200, 30);
        button.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
        button.addActionListener(this);
        this.add(button);

        this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if(e.getSource() == button){
            //System.out.println("anlebutton");
            String filePath = filePathText.getText();
            //System.out.println(filePath);
            InputStream in= null;
            try {
                in = new FileInputStream(filePath);
                boolean flag = readTxt(in);
                if( flag== true) {
                    JOptionPane.showMessageDialog(null, "Import success,please go to check", "Message:", JOptionPane.INFORMATION_MESSAGE);
                    this.dispose();
                }else{
                    JOptionPane.showMessageDialog(null, "Import failed,please go to check", "Message:", JOptionPane.INFORMATION_MESSAGE);
                    this.dispose();
                    return;
                }
            } catch (FileNotFoundException e1) {
                e1.printStackTrace();
            } catch (IOException e1) {
                e1.printStackTrace();
            }


        }
    }

    public static boolean readTxt(InputStream in) throws IOException {
        List<Student> list = new ArrayList<>();
        Student s = null;
        InputStreamReader inputStreamReader = new InputStreamReader(in);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        String lineTxt ;
        String Sid = null;
        String str;
        while ((lineTxt = bufferedReader.readLine()) != null)
        {
            str=lineTxt+"\r\n";
            String[] dictionary =  str.split("\\s{1,}|\t");
            Sid = dictionary[0];
            s = new Student(dictionary[0],dictionary[1],dictionary[2],dictionary[3],dictionary[4],dictionary[5],dictionary[6]);
            StudentDao dao = new StudentDao();
            int count = dao.querySid(Sid);
            //System.out.println(Sid.equals("") || !isNumber(Sid) || Sid.length() != 10 || count != 0);
            if(Sid.equals("") || !isNumber(Sid) || Sid.length() != 10 || count != 0){
                JOptionPane.showMessageDialog(null, Sid+"  Sid has been existed,please check.", "Message:", JOptionPane.WARNING_MESSAGE);
                return false;
            }else {
                dao.addStudent(s);
            }

        }
        return true;
    }


    public static boolean isNumber(String str){
        for (int i = 0; i < str.length(); i++) {
            int chr = str.charAt(i);
            if(chr < 48 || chr > 57){
                return false;
            }
        }
        return true;
    }


}
