package com.jsyunsi.view;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import com.jsyunsi.dao.UserDao;

public class ModifyPassWord extends JFrame implements ActionListener{
	
	private JLabel oldPassWord,newPassWord,confirmPassWord;
	private JTextField oldText,newText,confirmText;
	private JButton modify,cancel,back;
	
	public ModifyPassWord(){
		this.setTitle("������������Ϣ");
		this.setSize(450, 430);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		Font font = new Font("����",Font.BOLD,17);
		
		oldPassWord = new JLabel("ԭ����:");
		oldPassWord.setFont(font);
		oldPassWord.setBounds(40, 0, 100, 80);
		oldText = new JPasswordField();
		oldText.setBounds(120, 28, 200, 30);
		
		newPassWord = new JLabel("������:");
		newPassWord.setFont(font);
		newPassWord.setBounds(40, 90, 100, 80);
		newText = new JPasswordField();
		newText.setBounds(120, 120, 200, 30);
		
		confirmPassWord = new JLabel("ȷ������:");
		confirmPassWord.setFont(font);
		confirmPassWord.setBounds(40, 195, 100, 80);
		confirmText = new JPasswordField();
		confirmText.setBounds(120, 220, 200, 30);
		
		modify = new JButton("�޸�");
		modify.setBounds(20, 300, 80, 30);
		modify.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
		modify.addActionListener(this);
		
		cancel = new JButton("ȡ��");
		cancel.setBounds(140, 300, 80, 30);
		cancel.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		cancel.addActionListener(this);
		
		back = new JButton("����");
		back.setBounds(260, 300, 80, 30);
		back.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.red));
		back.addActionListener(this);
		
		this.add(oldPassWord);
		this.add(oldText);
		this.add(newPassWord);
		this.add(newText);
		this.add(confirmPassWord);
		this.add(confirmText);
		this.add(modify);
		this.add(cancel);
		this.add(back);
		this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		UserDao userDao = new UserDao();
		String passWord = userDao.getPassWordByUserName(Login.userName);
		if(e.getSource() == modify){
			String oldPassWord = oldText.getText();
			String newPassWord = newText.getText();
			String confirmPassWord = confirmText.getText();
			if(!oldPassWord.equals(passWord)){
				JOptionPane.showMessageDialog(null, "ԭ�������벻��ȷ", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
			}else if(!newPassWord.equals(confirmPassWord)){
				JOptionPane.showMessageDialog(null, "�����������벻һ�£�����������", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
			}else{
				if(newPassWord.equals("")){
					JOptionPane.showMessageDialog(null, "���벻��Ϊ��", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
					return;
				}
				int count = userDao.updatePassWord(newPassWord);
				if(count != 0){
					JOptionPane.showMessageDialog(null, "�޸ĳɹ�", "��Ϣ��ʾ", JOptionPane.INFORMATION_MESSAGE);
					this.dispose();
				}
			}
		}else if(e.getSource() == cancel){
			newText.setText("");
			confirmText.setText("");
		}else if(e.getSource() == back){
			this.dispose();
		}
	}
	
}
