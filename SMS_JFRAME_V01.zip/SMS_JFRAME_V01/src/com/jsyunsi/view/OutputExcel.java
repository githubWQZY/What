package com.jsyunsi.view;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import com.jsyunsi.dao.StudentDao;
import com.jsyunsi.entity.Student;

public class OutputExcel extends JFrame implements ActionListener{
	
	private JLabel label;
	private JButton button;
	private JTextField filePathText;
	public static void main(String[] args) {
		new OutputExcel();
	}
	public OutputExcel(){
		this.setTitle("������Excel");
		this.setSize(900, 500);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(HIDE_ON_CLOSE);
		this.setLayout(null);
		Font font = new Font("����",Font.BOLD,20);
		label = new JLabel("�ļ�:");
		label.setFont(font);
		label.setBounds(150, 105, 300, 60);
		this.add(label);
		
		filePathText = new JTextField();
		filePathText.setFont(font);
		filePathText.setBounds(300, 120, 300, 30);
		this.add(filePathText);
		
		button = new JButton("������Excel");
		button.setBounds(350, 300, 200, 30);
		button.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
		button.addActionListener(this);
		this.add(button);
		
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		StudentDao dao = new StudentDao();
		String[] data = new String[4];
		data[0] = "";
		data[1] = "";
		data[2] = "";
		data[3] = "";
		// TODO Auto-generated method stub
		if(e.getSource() == button){
			List<Student> list = dao.queryByCondition(data);
			String filePath = filePathText.getText();
			HSSFWorkbook  workbook = new HSSFWorkbook();
			HSSFSheet sheet = workbook.createSheet("ѧ����Ϣ");
			HSSFRow row = sheet.createRow(0);
			String[] rowHead = {"ѧ��","����","�Ա�","����","ʡ��","��Ȥ","�绰"};
			for (int i = 0; i < rowHead.length; i++) {
				row.createCell(i).setCellValue(rowHead[i]);
			}
			for (int i = 0; i < list.size(); i++) {
				HSSFRow r = sheet.createRow(i+1);
				Student stu = list.get(i);
				r.createCell(0).setCellValue(stu.getsId());
				r.createCell(1).setCellValue(stu.getsName());
				r.createCell(2).setCellValue(stu.getsSex());
				r.createCell(3).setCellValue(stu.getsBirthday());
				r.createCell(4).setCellValue(stu.getsProvince());
				r.createCell(5).setCellValue(stu.getsHobby());
				r.createCell(6).setCellValue(stu.getsPhone());
			}
			try {
				OutputStream out = new FileOutputStream(filePath);
				workbook.write(out);
				out.close();
				JOptionPane.showMessageDialog(null, "�����ɹ������Ʋ�������ĵ�ַ���в鿴", "��Ϣ��ʾ", JOptionPane.INFORMATION_MESSAGE);
				this.dispose();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

}
