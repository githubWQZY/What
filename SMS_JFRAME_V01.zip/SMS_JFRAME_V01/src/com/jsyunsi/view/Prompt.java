package com.jsyunsi.view;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

public class Prompt extends JFrame implements ActionListener{
	private JLabel msg;
	private JButton button1,button2;
	AddStudent add;
	public Prompt(AddStudent add){
		this.add = add;
		this.setTitle("���ӳɹ���ʾ��");
		this.setSize(550, 350);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		this.setResizable(false);
		this.setLayout(null);
		msg = new JLabel("���������Ϣ�Ѿ��ɹ����棬�Ƿ��������?");
		Font font = new Font("����",Font.BOLD,20);
		msg.setFont(font);
		msg.setBounds(50, 80, 450, 50);
		
		button1 = new JButton("��");
		button1.setFont(font);
		button1.setBounds(150, 150, 70, 40);
		button1.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		button1.addActionListener(this);
		
		button2 = new JButton("��");
		button2.setFont(font);
		button2.setBounds(300, 150, 70, 40);
		button2.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.red));
		button2.addActionListener(this);
		
		this.add(msg);
		this.add(button1);
		this.add(button2);
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == button1){
			this.dispose();
			this.add.clearText();
		}else if(e.getSource() == button2){
			this.dispose();
			this.add.dispose();
		}
	}
}
