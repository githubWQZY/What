package com.jsyunsi.view;

import java.awt.Event;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class MainMenu extends JFrame implements ActionListener{
	private JMenuBar jmb;
	private JMenu jm1,jm2,jm3;
	private JMenuItem jmi1,jmi2,jmi3,jmi4,jmi5,jmi6,jmi7,jmi8,jmi9,jmi10;
	public static void main(String[] args) {
		new MainMenu();
	}
	public MainMenu(){
		this.setTitle("��ӭʹ�����ѧ������ϵͳ");
		this.setIconImage(Toolkit.getDefaultToolkit().getImage("src/com/jsyunsi/images/logo.jpg"));
		this.setSize(800, 600);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//����˵�
		jm1 = new JMenu("��������(B)");
		jm1.setFont(new Font("����",Font.BOLD,16));
		jm1.setIcon(new ImageIcon("src/com/jsyunsi/icons/base1.png"));
		jm1.setMnemonic('B');
		
		jmb = new JMenuBar();
		
		jmi1 = new JMenuItem("����",new ImageIcon("src/com/jsyunsi/icons/add.png"));
		jmi1.setMnemonic('A');
		jmi1.setAccelerator(KeyStroke.getKeyStroke('A', Event.CTRL_MASK));
		
		jmi2 = new JMenuItem("��ѯ",new ImageIcon("src/com/jsyunsi/icons/query.png"));
		jmi2.setMnemonic('Q');
		jmi2.setAccelerator(KeyStroke.getKeyStroke('Q', Event.CTRL_MASK));
		
		jmi3 = new JMenuItem("�����޸�",new ImageIcon("src/com/jsyunsi/icons/modifyPassword.png"));
		jmi3.setMnemonic('U');
		jmi3.setAccelerator(KeyStroke.getKeyStroke('U', Event.CTRL_MASK));
		
		jmi4 = new JMenuItem("�˳�",new ImageIcon("src/com/jsyunsi/icons/exit.png"));
		jmi4.setMnemonic('E');
		jmi4.setAccelerator(KeyStroke.getKeyStroke('E', Event.CTRL_MASK));
		
		jm1.add(jmi1);
		jm1.add(jmi2);
		jm1.add(jmi3);
		jm1.add(jmi4);
		
		jm2 = new JMenu("���뵼��(i)");
		jm2.setFont(new Font("����",Font.BOLD,16));
		jm2.setIcon(new ImageIcon("src/com/jsyunsi/icons/base2.png"));
		jm2.setMnemonic('i');
		
		jmi5 = new JMenuItem("��excel����",new ImageIcon("src/com/jsyunsi/icons/import.png"));
		jmi5.setMnemonic('H');
		jmi5.setAccelerator(KeyStroke.getKeyStroke('H', Event.ALT_MASK));
		
		jmi6 = new JMenuItem("��txt����",new ImageIcon("src/com/jsyunsi/icons/import1.png"));
		jmi6.setMnemonic('H');
		jmi6.setAccelerator(KeyStroke.getKeyStroke('H', Event.ALT_MASK));
		
		jmi7 = new JMenuItem("��excel����",new ImageIcon("src/com/jsyunsi/icons/output.png"));
		jmi7.setMnemonic('H');
		jmi7.setAccelerator(KeyStroke.getKeyStroke('H', Event.ALT_MASK));
		
		jmi8 = new JMenuItem("��txt����",new ImageIcon("src/com/jsyunsi/icons/output1.png"));
		jmi8.setMnemonic('H');
		jmi8.setAccelerator(KeyStroke.getKeyStroke('H', Event.ALT_MASK));
		
		jm2.add(jmi5);
		jm2.add(jmi6);
		jm2.add(jmi7);
		jm2.add(jmi8);
		
		jm3 = new JMenu("����(H)");
		jm3.setFont(new Font("����",Font.BOLD,16));
		jm3.setIcon(new ImageIcon("src/com/jsyunsi/icons/base3.png"));
		jm3.setMnemonic('H');
		
		jmi9 = new JMenuItem("���ڱ�ϵͳ",new ImageIcon("src/com/jsyunsi/icons/about.png"));
		jmi9.setMnemonic('H');
		jmi9.setAccelerator(KeyStroke.getKeyStroke('H', Event.ALT_MASK));
		
		jmi10 = new JMenuItem("ϵͳ����",new ImageIcon("src/com/jsyunsi/icons/help.png"));
		jmi10.setMnemonic('H');
		jmi10.setAccelerator(KeyStroke.getKeyStroke('H', Event.ALT_MASK));
		
		jm3.add(jmi9);
		jm3.add(jmi10);
		
		jmb.add(jm1);
		jmb.add(jm2);
		jmb.add(jm3);
		this.setJMenuBar(jmb);
		this.setVisible(true);
		jmi1.addActionListener(this);
		jmi1.setActionCommand("Add");
		jmi2.addActionListener(this);
		jmi2.setActionCommand("Query");
		jmi3.addActionListener(this);
		jmi3.setActionCommand("Update");
		jmi4.addActionListener(this);
		jmi4.setActionCommand("Exit");
		jmi5.addActionListener(this);
		jmi5.setActionCommand("Iexcel");
		jmi6.addActionListener(this);
		jmi6.setActionCommand("Itxt");
		jmi7.addActionListener(this);
		jmi7.setActionCommand("Oexcel");
		jmi8.addActionListener(this);
		jmi8.setActionCommand("Otxt");
		jmi9.addActionListener(this);
		jmi9.setActionCommand("About");
		jmi10.addActionListener(this);
		jmi10.setActionCommand("Help");
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("Add")){
			new AddStudent();
		}else if(e.getActionCommand().equals("Query")){
			new QueryStudent();
		}else if(e.getActionCommand().equals("Update")){
			new ModifyPassWord();
		}else if(e.getActionCommand().equals("Exit")){
			int result = JOptionPane.showConfirmDialog(null, "ȷ���˳�?", "ȷ��", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
			if(result == JOptionPane.OK_OPTION) {
				System.exit(0);
			}
		}else if(e.getActionCommand().equals("Iexcel")){
				new ImportFromExcel();
		}else if(e.getActionCommand().equals("Itxt")){
			new ImportFromTxt();
		}else if(e.getActionCommand().equals("Oexcel")){
			new OutputExcel();
		}else if(e.getActionCommand().equals("Otxt")){
			new OutputTxt();
		}else if(e.getActionCommand().equals("About")){
			JOptionPane.showMessageDialog(null, "Nothing to Show!.", "Message:", JOptionPane.WARNING_MESSAGE);
		}else if(e.getActionCommand().equals("Help")){
			JOptionPane.showMessageDialog(null, "Nothing to Show!.", "Message:", JOptionPane.WARNING_MESSAGE);
		}
	}

}
