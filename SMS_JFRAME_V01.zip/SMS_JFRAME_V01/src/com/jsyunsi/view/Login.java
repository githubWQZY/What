package com.jsyunsi.view;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.Timer;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import com.jsyunsi.dao.UserDao;
import com.jsyunsi.entity.User;

public class Login extends JFrame implements ActionListener{
	public static String userName;
	public static String passWord;
	MyJpanel mj;
	//����ҳ�����ĸ���ǩ
	private JLabel jLabel_pageHead;
	private JLabel jLabel_pageFoot;
	private JLabel jLabel_userName;
	private JLabel jLabel_passWord;
	//����ҳ�������������
	private JTextField jUserNameField;
	private JTextField jPassWordField;
	//����������ť
	private JButton jLoginButton;
	private JButton jExitButton;
	int index = 0;
	ImageIcon[] imgs={
			new ImageIcon("src/com/jsyunsi/images/1.jpg"),
			new ImageIcon("src/com/jsyunsi/images/2.jpg"),
			new ImageIcon("src/com/jsyunsi/images/3.jpg"),
			new ImageIcon("src/com/jsyunsi/images/4.jpg"),
			new ImageIcon("src/com/jsyunsi/images/5.jpg"),
			new ImageIcon("src/com/jsyunsi/images/6.jpg")
	};
	public static void main(String[] args) {
		new Login();
	}
	public Login(){
		mj = new MyJpanel();
		mj.setBounds(0, 0, 1265, 420);
		this.add(mj);
		this.setTitle("��ӭ��½���ѧ������ϵͳ");
		this.setSize(1265, 856);
		this.setResizable(false);
		//���ô���Logo
		this.setIconImage(Toolkit.getDefaultToolkit().getImage("src/com/jsyunsi/images/logo.jpg"));
		//���ô��ھ���
		this.setLocationRelativeTo(null);
		//���ùر�ģʽ
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jLabel_pageHead = new JLabel("��ӭʹ�����ѧ������ϵͳ");
		jLabel_pageHead.setFont(new Font("����",Font.BOLD,40));
		jLabel_pageHead.setBounds(400, 440, 650, 50);
		
		Font font = new Font("����",Font.BOLD,15);
		jLabel_userName = new JLabel("�û���:");
		jLabel_userName.setFont(font);
		jLabel_userName.setBounds(430, 530, 70, 30);
		
		jLabel_passWord = new JLabel("����:");
		jLabel_passWord.setFont(font);
		jLabel_passWord.setBounds(430, 570, 70, 30);
		
		jLabel_pageFoot = new JLabel("���ݴ�ѧ��Ȩ����@ 2019 Copyrights all reserved ��ICP��15000567�� ���չ�������32425342521��");
		jLabel_pageFoot.setFont(new Font("����",Font.BOLD,10));
		jLabel_pageFoot.setBounds(400, 650, 670, 30);
		
		jUserNameField = new JTextField();
		jUserNameField.setBounds(520, 530, 150, 30);
		jPassWordField = new JPasswordField();
		jPassWordField.setBounds(520, 570, 150, 30);
		
		jLoginButton = new JButton("��¼");
		jLoginButton.setBounds(515, 625, 80, 25);
		jLoginButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		
		jExitButton = new JButton("�˳�");
		jExitButton.setBounds(610, 625, 80, 25);
		jExitButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		
		this.getRootPane().setDefaultButton(jLoginButton);
		this.setLayout(null);
		this.add(jLabel_pageHead);
		this.add(jLabel_userName);
		this.add(jLabel_passWord);
		this.add(jLabel_pageFoot);
		this.add(jLoginButton);
		this.add(jExitButton);
		this.add(jUserNameField);
		this.add(jPassWordField);
		
		this.setVisible(true);
		Timer timer = new Timer(2000,new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				mj.repaint();
			}
		});
		timer.start();
		jLoginButton.addActionListener(this);
		jExitButton.addActionListener(this);
	}
	private class MyJpanel extends JPanel{

		@Override
		public void paint(Graphics g) {
			super.paint(g);
			g.drawImage(imgs[index%imgs.length].getImage(), 0, 0, 1265, 420, null);
			index++;
		}
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		userName = jUserNameField.getText();
		passWord = jPassWordField.getText();
		UserDao userDao = new UserDao();
		User user = userDao.checkLogin(userName, passWord);
		if(e.getSource() == jLoginButton){
			if(null == user){
				JOptionPane.showMessageDialog(null, "�û��������������", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
			}else{
				System.out.println("��¼�ɹ�");
				this.setVisible(false);
				//����������
				new MainMenu();
			}
		}else if(e.getSource() == jExitButton){
			System.exit(0);
		}
		
	}
	
}
