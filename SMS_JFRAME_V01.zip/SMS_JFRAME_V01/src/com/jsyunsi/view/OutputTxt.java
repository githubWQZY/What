package com.jsyunsi.view;

import com.jsyunsi.dao.StudentDao;
import com.jsyunsi.entity.Student;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.List;

public class OutputTxt extends JFrame implements ActionListener {

    private JLabel label;
    private JButton button;
    private JTextField filePathText;
    public static void main(String[] args) {
        new OutputExcel();
    }
    public OutputTxt(){
        this.setTitle("ExportTotxt");
        this.setSize(900, 500);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        this.setLayout(null);
        Font font = new Font("楷体",Font.BOLD,20);
        label = new JLabel("File:");
        label.setFont(font);
        label.setBounds(150, 105, 300, 60);
        this.add(label);

        filePathText = new JTextField();
        filePathText.setFont(font);
        filePathText.setBounds(300, 120, 300, 30);
        this.add(filePathText);

        button = new JButton("ExportTotxt");
        button.setBounds(350, 300, 200, 30);
        button.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
        button.addActionListener(this);
        this.add(button);

        this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        StudentDao dao = new StudentDao();
        String[] data = new String[4];
        data[0] = "";
        data[1] = "";
        data[2] = "";
        data[3] = "";
        // TODO Auto-generated method stub
        if(e.getSource() == button){
            List<Student> list = dao.queryByCondition(data);
            String filePath = filePathText.getText();
            if (filePath.equals("")){
                JOptionPane.showMessageDialog(null, "Invalid filePath,please check your input", "Message:", JOptionPane.INFORMATION_MESSAGE);
            }else {
                try {
                    File file = new File(filePath);
                    if (!file.isFile()) {
                        file.createNewFile();
                    }
                    BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
                    for (Student l : list) {
                        writer.write(l + "\r\n");
                    }
                    writer.close();

                    JOptionPane.showMessageDialog(null, "Export success,please go to check", "Message:", JOptionPane.INFORMATION_MESSAGE);
                    this.dispose();
                } catch (Exception e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }
        }
    }

}

