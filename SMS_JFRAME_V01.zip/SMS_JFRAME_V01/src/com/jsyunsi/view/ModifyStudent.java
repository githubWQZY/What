package com.jsyunsi.view;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import com.jsyunsi.dao.StudentDao;
import com.jsyunsi.entity.Student;

public class ModifyStudent extends JFrame implements ActionListener,ItemListener{
	//�������еı�ǩ��
	private JLabel sId,sName,sSex,sBirthday,sProvince,sHobby,sPhone;
	//�����ĸ��ı���
	private JTextField sIdText,sNameText,sBirthdayText,sPhoneText;
	//����һ�鵥ѡ����ѡ��
	private ButtonGroup sexButton;
	private JRadioButton sexButton1,sexButton2;
	//����һ��ʡ��������
	private JComboBox sProvinceComboBox;
	private String[] province = {"������ʡ","����ʡ","����ʡ","�ӱ�ʡ","����ʡ",
			"����ʡ","����ʡ","ɽ��ʡ","ɽ��ʡ","����ʡ","����ʡ","�㽭ʡ",
			"����ʡ","����ʡ","�㶫ʡ","����ʡ","�Ĵ�ʡ","����ʡ","����ʡ",
			"�ຣʡ","����ʡ","����ʡ","̨��ʡ"};
	//����һ����Ȥ���õĸ�ѡ��(���������)
	private static JPanel checkBox;
	private JCheckBox hobby1,hobby2,hobby3,hobby4,hobby5,hobby6,
	hobby7,hobby8,hobby9,hobby10,hobby11,hobby12;
	//����������ť
	private JButton save,cancel,back;
	
	public ModifyStudent(Student student){
		this.setTitle("�޸�ѧ����Ϣ");
		this.setIconImage(Toolkit.getDefaultToolkit().getImage("src/com/jsyunsi/images/logo.jpg"));
		this.setSize(850, 650);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		this.setLayout(null);
		Font font = new Font("����",Font.BOLD,20);
		sId = new JLabel("ѧ��:");
		sId.setFont(font);
		sId.setBounds(250, 30, 150, 50);
		sIdText = new JTextField();
		sIdText.setFont(font);
		sIdText.setBounds(350, 40, 150, 30);
		
		sName = new JLabel("����:");
		sName.setFont(font);
		sName.setBounds(250, 90, 150, 50);
		sNameText = new JTextField();
		sNameText.setFont(font);
		sNameText.setBounds(350, 100, 150, 30);
		
		sSex = new JLabel("�Ա�:");
		sSex.setFont(font);
		sSex.setBounds(250, 150, 150, 50);
		
		sexButton = new ButtonGroup();
		sexButton1 = new JRadioButton("��");
		sexButton1.setFont(font);
		sexButton1.setBounds(350, 160, 50, 30);
		sexButton2 = new JRadioButton("Ů");
		sexButton2.setFont(font);
		sexButton2.setBounds(450, 160, 50, 30);
		sexButton.add(sexButton1);
		sexButton.add(sexButton2);
		
		sBirthday = new JLabel("��������:");
		sBirthday.setFont(font);
		sBirthday.setBounds(250, 210, 150, 50);
		sBirthdayText = new JTextField();
		sBirthdayText.setFont(font);
		sBirthdayText.setBounds(350, 220, 150, 30);
		
		sProvince = new JLabel("����ʡ��:");
		sProvince.setFont(font);
		sProvince.setBounds(250, 270, 150, 50);
		sProvinceComboBox = new JComboBox(province);
		sProvinceComboBox.setFont(font);
		sProvinceComboBox.setBounds(350, 280, 150, 30);
		
		sHobby = new JLabel("��Ȥ����:");
		sHobby.setFont(font);
		sHobby.setBounds(250, 330, 150, 50);
		hobby1 = new JCheckBox("����");
		hobby1.setFont(font);
		hobby2 = new JCheckBox("����");
		hobby2.setFont(font);
		hobby3 = new JCheckBox("ƹ����");
		hobby3.setFont(font);
		hobby4 = new JCheckBox("����Ӱ");
		hobby4.setFont(font);
		hobby5 = new JCheckBox("��ë��");
		hobby5.setFont(font);
		hobby6 = new JCheckBox("��Ӿ");
		hobby6.setFont(font);
		hobby7 = new JCheckBox("����");
		hobby7.setFont(font);
		hobby8 = new JCheckBox("����");
		hobby8.setFont(font);
		hobby9 = new JCheckBox("����Ϸ");
		hobby9.setFont(font);
		hobby10 = new JCheckBox("���");
		hobby10.setFont(font);
		hobby11 = new JCheckBox("����");
		hobby11.setFont(font);
		hobby12 = new JCheckBox("����");
		hobby12.setFont(font);
		
		checkBox = new JPanel();
		checkBox.setBounds(350, 335, 390, 130);
		checkBox.setLayout(new GridLayout(3,4));
		checkBox.add(hobby1);
		checkBox.add(hobby2);
		checkBox.add(hobby3);
		checkBox.add(hobby4);
		checkBox.add(hobby5);
		checkBox.add(hobby6);
		checkBox.add(hobby7);
		checkBox.add(hobby8);
		checkBox.add(hobby9);
		checkBox.add(hobby10);
		checkBox.add(hobby11);
		checkBox.add(hobby12);
		
		sPhone = new JLabel("��ϵ�绰:");
		sPhone.setFont(font);
		sPhone.setBounds(250, 460, 150, 50);
		sPhoneText = new JTextField();
		sPhoneText.setFont(font);
		sPhoneText.setBounds(350, 470, 150, 30);
		
		Font font2 = new Font("����",Font.BOLD,15);
		save = new JButton("����");
		save.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		save.setFont(font2);
		save.setBounds(250, 520, 70, 30);
		cancel = new JButton("ȡ��");
		cancel.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.red));
		cancel.setFont(font2);
		cancel.setBounds(350, 520, 70, 30);
		back = new JButton("����");
		back.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		back.setFont(font2);
		back.setBounds(450, 520, 70, 30);
		
		this.add(save);
		this.add(cancel);
		this.add(back);
		this.add(sPhone);
		this.add(sPhoneText);
		this.add(sHobby);
		this.add(checkBox);
		this.add(sProvince);
		this.add(sProvinceComboBox);
		this.add(sBirthday);
		this.add(sBirthdayText);
		this.add(sSex);
		this.add(sexButton1);
		this.add(sexButton2);
		this.add(sId);
		this.add(sIdText);
		this.add(sName);
		this.add(sNameText);
		sIdText.addActionListener(this);
		sNameText.addActionListener(this);
		sBirthdayText.addActionListener(this);
		sProvinceComboBox.addActionListener(this);
		hobby1.addActionListener(this);
		hobby2.addActionListener(this);
		hobby3.addActionListener(this);
		hobby4.addActionListener(this);
		hobby5.addActionListener(this);
		hobby6.addActionListener(this);
		hobby7.addActionListener(this);
		hobby8.addActionListener(this);
		hobby9.addActionListener(this);
		hobby10.addActionListener(this);
		hobby11.addActionListener(this);
		hobby12.addActionListener(this);
		sPhoneText.addActionListener(this);
		
		save.addActionListener(this);
		cancel.addActionListener(this);
		back.addActionListener(this);
		this.setVisible(true);


	}
	
	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String sId = sIdText.getText();
		String sName = sNameText.getText();
		String sBirthday = sBirthdayText.getText();
		String sPhone = sPhoneText.getText();
		if(e.getSource() == sIdText){
			sNameText.requestFocus();
		}else if(e.getSource() == sNameText){
			sBirthdayText.requestFocus();
		}else if(e.getSource() == sBirthdayText){
			sPhoneText.requestFocus();
		}else if(e.getSource() == save){
			//��ѧ�Ž��зǿա���ʽ��Ψһ���ж�
			
			StudentDao dao = new StudentDao();
			if(sName.equals("")){
				JOptionPane.showMessageDialog(null, "��������Ϊ��", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
				return;
			}
			if(!sexButton1.isSelected() && !sexButton2.isSelected()){
				JOptionPane.showMessageDialog(null, "��ѡ���Ա�", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
				return;
			}
			if(sBirthday.equals("")){
				JOptionPane.showMessageDialog(null, "�������ڲ���Ϊ��", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
				return;
			}
			if(!isDate(sBirthday)){
				JOptionPane.showMessageDialog(null, "�������ڸ�ʽ���Ϸ�������������", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
				return;
			}
			if(!hobby1.isSelected() && !hobby2.isSelected() && !hobby3.isSelected()
					 && !hobby4.isSelected() && !hobby5.isSelected() && !hobby6.isSelected()
					 && !hobby7.isSelected() && !hobby8.isSelected() && !hobby9.isSelected()
					 && !hobby10.isSelected() && !hobby11.isSelected() && !hobby12.isSelected()){
				JOptionPane.showMessageDialog(null, "��Ȥ���ò���Ϊ��", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
				return;
			}
			if(sPhone.equals("")){
				JOptionPane.showMessageDialog(null, "�绰���벻��Ϊ��", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
				return;
			}
			if(!isMobile(sPhone)){
				JOptionPane.showMessageDialog(null, "�绰�����ʽ����", "��Ϣ��ʾ", JOptionPane.WARNING_MESSAGE);
				return;
			}
			String sSex = null;
			if(sexButton1.isSelected()){
				sSex = sexButton1.getText();
			}else{
				sSex = sexButton2.getText();
			}
			String sProvince = (String) sProvinceComboBox.getSelectedItem();	
			StringBuffer buffer = new StringBuffer();
			if(hobby1.isSelected()){
				buffer.append(hobby1.getText()+",");
			}
			if(hobby1.isSelected()){
				buffer.append(hobby1.getText()+",");
			}
			if(hobby2.isSelected()){
				buffer.append(hobby2.getText()+",");
			}
			if(hobby3.isSelected()){
				buffer.append(hobby3.getText()+",");
			}
			if(hobby4.isSelected()){
				buffer.append(hobby4.getText()+",");
			}
			if(hobby5.isSelected()){
				buffer.append(hobby5.getText()+",");
			}
			if(hobby6.isSelected()){
				buffer.append(hobby6.getText()+",");
			}
			if(hobby7.isSelected()){
				buffer.append(hobby7.getText()+",");
			}
			if(hobby8.isSelected()){
				buffer.append(hobby8.getText()+",");
			}
			if(hobby9.isSelected()){
				buffer.append(hobby9.getText()+",");
			}
			if(hobby10.isSelected()){
				buffer.append(hobby10.getText()+",");
			}
			if(hobby11.isSelected()){
				buffer.append(hobby11.getText()+",");
			}
			if(hobby12.isSelected()){
				buffer.append(hobby12.getText());
			}
			if(buffer.charAt(buffer.length() - 1) == ','){
				buffer.deleteCharAt(buffer.length()-1);
			}
			String sHobby = buffer.toString();
			Student student = new Student(sId,sName,sSex,sBirthday,sProvince,sHobby,sPhone);
			//
		}else if(e.getSource() == cancel){
			clearText();
		}else if(e.getSource() == back){
			this.dispose();
		}
		
	}
	public boolean isNumber(String str){
		for (int i = 0; i < str.length(); i++) {
			int chr = str.charAt(i);
			if(chr < 48 || chr > 57){
				return false;
			}
		}
		return true;
	}
	public  boolean isMobile(String sphone) {
		Pattern p = null;
		Matcher m = null;
		boolean b = false;
		p = Pattern.compile("^[1][3,4,5,7,8][0-9]{9}$"); // ��֤�ֻ��Űѹ�������ģʽ����
		m = p.matcher(sphone);//ͨ��ģʽ����õ�ƥ��������
		b = m.matches();//��ƥ��Ŀ����м��
		return b;
	}
	public void clearText(){
		sNameText.setText("");
		sexButton.clearSelection();
		sBirthdayText.setText("");
		sProvinceComboBox.setSelectedIndex(0);
		hobby1.setSelected(false);
		hobby2.setSelected(false);
		hobby3.setSelected(false);
		hobby4.setSelected(false);
		hobby5.setSelected(false);
		hobby6.setSelected(false);
		hobby7.setSelected(false);
		hobby8.setSelected(false);
		hobby9.setSelected(false);
		hobby10.setSelected(false);
		hobby11.setSelected(false);
		sPhoneText.setText("");
		
	}
	public boolean isDate(String date)
	{
		/**
		 * �ж����ڸ�ʽ�ͷ�Χ
		 */
		String rexp = "^((\\d{2}(([02468][048])"
				+ "|([13579][26]))[\\-\\/\\s]?"
				+ "((((0?[13578])|(1[02]))[\\-\\/\\s]?"
				+ "((0?[1-9])|([1-2][0-9])|(3[01])))"
				+ "|(((0?[469])|(11))[\\-\\/\\s]?"
				+ "((0?[1-9])|([1-2][0-9])|(30)))"
				+ "|(0?2[\\-\\/\\s]?((0?[1-9])"
				+ "|([1-2][0-9])))))|(\\d{2}(([02468][1235679])"
				+ "|([13579][01345789]))[\\-\\/\\s]?"
				+ "((((0?[13578])|(1[02]))[\\-\\/\\s]?"
				+ "((0?[1-9])|([1-2][0-9])|(3[01])))"
				+ "|(((0?[469])|(11))[\\-\\/\\s]?"
				+ "((0?[1-9])|([1-2][0-9])|(30)))"
				+ "|(0?2[\\-\\/\\s]?((0?[1-9])"
				+ "|(1[0-9])|(2[0-8]))))))";

		Pattern pat = Pattern.compile(rexp);   //�ѹ�������ģʽ����

		Matcher mat = pat.matcher(date);    //ͨ��ģʽ����õ�ƥ��������

		boolean dateType = mat.matches();  //��ƥ��Ŀ����м��

		return dateType;
	}

}
