package com.jsyunsi.entity;

public class Student {
	private String sId;
	private String sName;
	private String sSex;
	private String sBirthday;
	private String sProvince;
	private String sHobby;
	private String sPhone;
	public String getsId() {
		return sId;
	}
	public void setsId(String sId) {
		this.sId = sId;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsSex() {
		return sSex;
	}
	public void setsSex(String sSex) {
		this.sSex = sSex;
	}
	public String getsBirthday() {
		return sBirthday;
	}
	public void setsBirthday(String sBirthday) {
		this.sBirthday = sBirthday;
	}
	public String getsProvince() {
		return sProvince;
	}
	public void setsProvince(String sProvince) {
		this.sProvince = sProvince;
	}
	public String getsHobby() {
		return sHobby;
	}
	public void setsHobby(String sHobby) {
		this.sHobby = sHobby;
	}
	public String getsPhone() {
		return sPhone;
	}
	public void setsPhone(String sPhone) {
		this.sPhone = sPhone;
	}

	public Student(){

	}
	public Student(String sId, String sName, String sSex, String sBirthday, String sProvince, String sHobby,
			String sPhone) {
		super();
		this.sId = sId;
		this.sName = sName;
		this.sSex = sSex;
		this.sBirthday = sBirthday;
		this.sProvince = sProvince;
		this.sHobby = sHobby;
		this.sPhone = sPhone;
	}
	@Override
	public String toString() {
		return "Student [sId=" + sId + ", sName=" + sName + ", sSex=" + sSex + ", sBirthday=" + sBirthday
				+ ", sProvince=" + sProvince + ", sHobby=" + sHobby + ", sPhone=" + sPhone + "]";
	}
	
}
