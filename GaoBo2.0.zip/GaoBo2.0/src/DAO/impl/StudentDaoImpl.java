package DAO.impl;

import DAO.StudentDao;
import com.gem.exam.servlets.DbConnection;
import model.Student;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StudentDaoImpl  implements StudentDao {

    PreparedStatement prst = null;
    ResultSet rs = null;
    DbConnection Dbconn = new DbConnection();

    @Override
    public List<Student> getStudentList() {
        List<Student> list = new ArrayList<Student>();
        try {
            prst = Dbconn.conn.prepareStatement("select * from studenttable");
            rs = prst.executeQuery( );
            while (rs.next()) {
                Student student = new Student(rs.getString(1), rs.getString(2),
                        rs.getString(3), rs.getString(4),
                        rs.getString(5), rs.getLong(6),
                        rs.getString(7), rs.getString(8),
                        rs.getString(9), rs.getString(10),
                        rs.getString(11), rs.getString(12),
                        rs.getString(13), rs.getLong(16),
                        rs.getLong(17), rs.getString(18)
                );
                list.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean addStudent(Student student) {
        return false;
    }

    @Override
    public boolean updateStudent(Student student) {
        return false;
    }

    @Override
    public Student getStudent(String sno) {
        return null;
    }

    @Override
    public boolean delStudent(String sno) {
        return false;
    }
}
