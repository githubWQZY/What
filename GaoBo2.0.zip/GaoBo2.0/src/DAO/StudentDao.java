package DAO;

import model.Student;

import java.util.List;

public interface StudentDao {
    //获取学生信息
    public List<Student> getStudentList();
    //添加学生信息
    public boolean addStudent(Student student);
    //修改指定学生信息
    public boolean updateStudent(Student student);
    //查看特定学生信息
    public Student getStudent(String sno);
    //删除指定学生信息
    public boolean delStudent(String sno);
}
