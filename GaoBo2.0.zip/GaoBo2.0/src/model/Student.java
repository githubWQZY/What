package model;


public class Student {

  private String sno;
  private String spwd;
  private String sname;
  private String spoli;
  private String sgender;
  private long sage;
  private String sadd;
  private String sdep;
  private String smajor;
  private String sclass;
  private String tno;
  private String stel;
  private String sEmail;
  private String sphoto;
  private String svideo;
  private long stall;
  private long sweight;
  private String sann;
public Student(){ }

  public Student(String sno, String spwd, String sname, String spoli, String sgender,
                 long sage, String sadd, String sdep, String smajor,
                 String sclass, String tno, String stel, String sEmail,
                 long stall, long sweight, String sann) {
    this.sno = sno;
    this.spwd = spwd;
    this.sname = sname;
    this.spoli = spoli;
    this.sgender = sgender;
    this.sage = sage;
    this.sadd = sadd;
    this.sdep = sdep;
    this.smajor = smajor;
    this.sclass = sclass;
    this.tno = tno;
    this.stel = stel;
    this.sEmail = sEmail;
    this.stall = stall;
    this.sweight = sweight;
    this.sann = sann;
  }

  public String getSno() {
    return sno;
  }

  public void setSno(String sno) {
    this.sno = sno;
  }


  public String getSpwd() {
    return spwd;
  }

  public void setSpwd(String spwd) {
    this.spwd = spwd;
  }


  public String getSname() {
    return sname;
  }

  public void setSname(String sname) {
    this.sname = sname;
  }


  public String getSpoli() {
    return spoli;
  }

  public void setSpoli(String spoli) {
    this.spoli = spoli;
  }


  public String getSgender() {
    return sgender;
  }

  public void setSgender(String sgender) {
    this.sgender = sgender;
  }


  public long getSage() {
    return sage;
  }

  public void setSage(long sage) {
    this.sage = sage;
  }


  public String getSadd() {
    return sadd;
  }

  public void setSadd(String sadd) {
    this.sadd = sadd;
  }


  public String getSdep() {
    return sdep;
  }

  public void setSdep(String sdep) {
    this.sdep = sdep;
  }


  public String getSmajor() {
    return smajor;
  }

  public void setSmajor(String smajor) {
    this.smajor = smajor;
  }


  public String getSclass() {
    return sclass;
  }

  public void setSclass(String sclass) {
    this.sclass = sclass;
  }


  public String getTno() {
    return tno;
  }

  public void setTno(String tno) {
    this.tno = tno;
  }


  public String getStel() {
    return stel;
  }

  public void setStel(String stel) {
    this.stel = stel;
  }


  public String getSEmail() {
    return sEmail;
  }

  public void setSEmail(String sEmail) {
    this.sEmail = sEmail;
  }


  public String getSphoto() {
    return sphoto;
  }

  public void setSphoto(String sphoto) {
    this.sphoto = sphoto;
  }


  public String getSvideo() {
    return svideo;
  }

  public void setSvideo(String svideo) {
    this.svideo = svideo;
  }


  public long getStall() {
    return stall;
  }

  public void setStall(long stall) {
    this.stall = stall;
  }


  public long getSweight() {
    return sweight;
  }

  public void setSweight(long sweight) {
    this.sweight = sweight;
  }


  public String getSann() {
    return sann;
  }

  public void setSann(String sann) {
    this.sann = sann;
  }

}
