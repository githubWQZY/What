package com.gem.exam.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name="LoginOutPage",urlPatterns = {"/LoginOutPage"})
public class LoginOutPage extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");//这两句对于中文乱码很重要了
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        if(request.getSession(false)!=null){
            request.getSession().removeAttribute("sno");
            request.getSession().invalidate();
            out.println("您已退出系统，3秒后系统返回首页。");
            out.println("<meta http-equiv=\"refresh\" content=\"3;url=index.jsp\" />");
            out.println("    <style>\n" +
                    "        body{\n" +
                    "            margin: 0px auto;\n" +
                    "            background-image: url(\"./resources/images/001.jpg\");\n" +
                    "        }\n" +
                    "    </style>\n");
        }
    }
}
