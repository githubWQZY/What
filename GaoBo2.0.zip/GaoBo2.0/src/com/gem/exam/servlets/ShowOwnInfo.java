package com.gem.exam.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@WebServlet(name="ShowOwnInfo",urlPatterns = {"/ShowOwnInfo"})
public class ShowOwnInfo extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");//这两句对于中文乱码很重要了
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        DbConnection Dbconn = new DbConnection();
        PreparedStatement prst = null;
        ResultSet rs = null;
        Map<String,Object> map = new HashMap<String,Object>();
        String sno = (String) request.getSession().getAttribute("sno");
        String msno = (String) request.getSession().getAttribute("msno");

        //out.println("要进try"+sno);
        try{
            if(sno !=null) {
                String sql = "select * from StudentTable where Sno=?;";
                prst = Dbconn.conn.prepareStatement(sql);
                prst.setString(1, sno);
                rs = prst.executeQuery();
                if(rs.next()) {

                    out.println("<html>\n" +
                            "<head>\n" +
                            "    <meta charset=\"utf-8\">\n" +
                            "    <title>学生基础信息管理系统</title>\n" +
                            "    <meta name=\"renderer\" content=\"webkit\">\n" +
                            "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\n" +
                            "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\">\n" +
                            "    <link rel=\"stylesheet\" href=\"./resources/layui/css/layui.css\"  media=\"all\">\n" +
                            "    <!-- 注意：如果你直接复制所有代码到本地，上述css路径需要改成你本地的 -->\n" +
                            "    <style>\n" +
                            "        body{\n" +
                            "            margin: 0px auto;\n" +
                            "            background-image: url(\"./resources/images/001.jpg\");\n" +
                            "        }\n" +
                            "    </style>\n" +
                            "</head>\n" +
                            "<body>\n" +
                            "<div style=\"margin-top: 20px\">\n" +
                            "    <h2>以下是您的基本信息，修改信息请前往个人中心。</h2>\n" +
                            "</div>\n" +
                            "<table class=\"layui-table\"  lay-filter=\"test3\">\n" +
                            "    <thead>\n" +
                            "    <tr>\n" +
                            "        <th lay-data=\"{field:'Sno', width:80}\">学号</th>\n" +
                            "        <th lay-data=\"{field:'Sname', width:120, edit: 'text'}\">姓名</th>\n" +
                            "        <th lay-data=\"{field:'Sclass', edit: 'text', minWidth: 150}\">班级</th>\n" +
                            "        <th lay-data=\"{field:'Smajor', edit: 'text', minWidth: 100}\">专业</th>\n" +
                            "        <th lay-data=\"{field:'Sdep',  edit: 'text'}\">学院</th>\n" +
                            "        <th lay-data=\"{field:'Sage', width:80, edit: 'text'}\">年龄</th>\n" +
                            "        <th lay-data=\"{field:'Sgender', width:80, edit: 'text'}\">性别</th>\n" +
                            "        <th lay-data=\"{field:'Stel', width:80, }\">电话</th>\n" +
                            "        <th lay-data=\"{field:'SEmail', edit: 'text', minWidth: 150}\">邮箱</th>\n" +
                            "        <th lay-data=\"{field:'Sadd', edit: 'text'}\">籍贯</th>\n" +
                            "        <th lay-data=\"{field:'STea', width:120,  edit: 'text'}\">班主任</th>\n" +
                            "    </tr>\n" +
                            "    </thead>\n" );
                    out.print("<tr>");
                    out.print("<td onclick=\"test()\">" + sno + "</td>");
                    out.print("<td>" + rs.getString("Sname") + "</td>");
                    out.print("<td>" + rs.getString("Sclass") + "</td>");
                    out.print("<td >" + rs.getString("Smajor") + "</td>");
                    out.print("<td>" + rs.getString("Sdep") + "</td>");
                    out.print("<td>" + rs.getString("Sage") + "</td>");
                    out.print("<td>" + rs.getString("Sgender") + "</td>");
                    out.print("<td>" + rs.getString("Stel") + "</td>");
                    out.print("<td>" + rs.getString("SEmail") + "</td>");
                    out.print("<td>" + rs.getString("Sadd") + "</td>");
                    out.print("<td>" + rs.getString("Tno") + "</td>");
                    out.print("</tr>");
                    out.println("</table>\n" );
                    out.println("<div>");
                    out.println("<h3>照片</h3><div  id=\"Sphoto\" style=\"display:inline-block\">\n" +
                            "<img style=\"padding-top:10px ;padding-left: 55%\" src=\""+rs.getString("Sphoto")+"\">\n" +
                            "</div>");
                    out.println("</div>");
                    out.println("</div>");
                    out.println("<script src=\"./resources/layui/layui.js\" charset=\"utf-8\"></script>\n" +
                            "<!-- 注意：如果你直接复制所有代码到本地，上述js路径需要改成你本地的 -->\n" +
                            "<script>\n" );
                    out.println("");
                    out.println( "</script>\n" +
                            "\n" +
                            "</body>\n" +
                            "</html>");
                }
            }else {
                String sql = "select * from SystemManagerTable where msno=?;";
                prst = Dbconn.conn.prepareStatement(sql);
                prst.setString(1, msno);
                rs = prst.executeQuery();
                if(rs.next()) {

                    out.println("<html>\n" +
                            "<head>\n" +
                            "    <meta charset=\"utf-8\">\n" +
                            "    <title>学生基础信息管理系统</title>\n" +
                            "    <meta name=\"renderer\" content=\"webkit\">\n" +
                            "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\n" +
                            "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\">\n" +
                            "    <link rel=\"stylesheet\" href=\"./resources/layui/css/layui.css\"  media=\"all\">\n" +
                            "    <!-- 注意：如果你直接复制所有代码到本地，上述css路径需要改成你本地的 -->\n" +
                            "    <style>\n" +
                            "        body{\n" +
                            "            margin: 0px auto;\n" +
                            "            background-image: url(\"./resources/images/001.jpg\");\n" +
                            "        }\n" +
                            "    </style>\n" +
                            "</head>\n" +
                            "<body>\n" +
                            "<div style=\"margin-top: 20px\">\n" +
                            "    <h2>以下是您的基本信息，修改信息请前往个人中心。</h2>\n" +
                            "</div>\n" +
                            "<table class=\"layui-table\"  lay-filter=\"test3\">\n" +
                            "    <thead>\n" +
                            "    <tr>\n" +
                            "        <th lay-data=\"{field:'MSno', width:80}\">工号</th>\n" +
                            "        <th lay-data=\"{field:'MSname', width:120, edit: 'text'}\">姓名</th>\n" +
                            "        <th lay-data=\"{field:'Spwd',  edit: 'text'}\">密码</th>\n" +
                            "        <th lay-data=\"{field:'MSage', width:80, edit: 'text'}\">年龄</th>\n" +
                            "        <th lay-data=\"{field:'MSgender', width:80, edit: 'text'}\">性别</th>\n" +
                            "        <th lay-data=\"{field:'MStel', width:80, }\">电话</th>\n" +
                            "        <th lay-data=\"{field:'MSEmail', edit: 'text', minWidth: 150}\">邮箱</th>\n" +
                            "    </thead>\n" );
                    out.print("<tr>");
                    out.print("<td onclick=\"test()\">" + msno + "</td>");
                    out.print("<td>" + rs.getString("mSname") + "</td>");
                    out.print("<td>" + rs.getString("mSpwd") + "</td>");
                    out.print("<td>" + rs.getString("mSage") + "</td>");
                    out.print("<td>" + rs.getString("mSgender") + "</td>");
                    out.print("<td>" + rs.getString("mStel") + "</td>");
                    out.print("<td>" + rs.getString("mSEmail") + "</td>");
                    out.print("</tr>");
                    out.println("</table>\n" );
                    out.println("</div>");
                    out.println("</div>");
                    out.println("<script src=\"./resources/layui/layui.js\" charset=\"utf-8\"></script>\n" +
                            "<!-- 注意：如果你直接复制所有代码到本地，上述js路径需要改成你本地的 -->\n" +
                            "<script>\n" );
                    out.println("");
                    out.println( "</script>\n" +
                            "\n" +
                            "</body>\n" +
                            "</html>");
                }

            }


        }catch (SQLException e){
            e.printStackTrace();
        }
    }
}
