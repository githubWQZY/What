package com.gem.exam.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet(name = "AddStudent",urlPatterns = {"/AddStudent"})
public class AddStudent extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");//这两句对于中文乱码很重要了
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        DbConnection Dbconn = new DbConnection();
        PreparedStatement prst = null;
        ResultSet rs = null;
//out.println("来改密码的？");
        String sno = request.getParameter("sno");
        String sname = request.getParameter("sname");
        String sclass = request.getParameter("sclass");
        String major = request.getParameter("major");
        String sdep = request.getParameter("sdep");
        String semail = request.getParameter("semail");
        String stel = request.getParameter("stel");
        String spwd = request.getParameter("password");
        //System.out.println(sno+"  "+spwd);
        if(request.getSession().getAttribute("msno")!=null){
            try{
                String sql = "insert into StudentTable (sno,sname,sclass,smajor,sdep,semail,stel,Spwd)" +
                        "values (?,?,?,?,?,?,?,?)";
                prst = Dbconn.conn.prepareStatement(sql);
                prst.setString(1, sno);
                prst.setString(2, sname);
                prst.setString(3, sclass);
                prst.setString(4, major);
                prst.setString(5, sdep);
                prst.setString(6, semail);
                prst.setString(7, stel);
                prst.setString(8, spwd);
                int num = prst.executeUpdate();
                if(num==1){

                    out.println("插入成功,3秒后自动返回。");
                    out.println("<meta http-equiv=\"refresh\" content=\"3;url=ManagerPage.jsp\" />");
                    out.println("    <style>\n" +
                            "        body{\n" +
                            "            margin: 0px auto;\n" +
                            "            background-image: url(\"./resources/images/001.jpg\");\n" +
                            "        }\n" +
                            "    </style>\n");
                }else {
                    out.println("出错，请检查信息重新尝试修改。3秒后系统自动返回上一页面。");
                    out.println("<meta http-equiv=\"refresh\" content=\"3;url=ManagerPage.jsp\" />");
                    out.println("    <style>\n" +
                            "        body{\n" +
                            "            margin: 0px auto;\n" +
                            "            background-image: url(\"./resources/images/001.jpg\");\n" +
                            "        }\n" +
                            "    </style>\n");
                }
            }catch (SQLException e){
                e.printStackTrace();

                out.println("出错，请重新尝试。");
                out.println("<meta http-equiv=\"refresh\" content=\"3;url=ManagerPage.jsp\" />");
                out.println("    <style>\n" +
                        "        body{\n" +
                        "            margin: 0px auto;\n" +
                        "            background-image: url(\"./resources/images/001.jpg\");\n" +
                        "        }\n" +
                        "    </style>\n");
            }
        }else{
            out.println("请先登录系统。");
            out.println("<meta http-equiv=\"refresh\" content=\"3;url=index.jsp\" />");
            out.println("    <style>\n" +
                    "        body{\n" +
                    "            margin: 0px auto;\n" +
                    "            background-image: url(\"./resources/images/001.jpg\");\n" +
                    "        }\n" +
                    "    </style>\n");
        }

    }
}
