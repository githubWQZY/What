package com.gem.exam.servlets;

        import java.sql.Connection;
        import java.sql.DriverManager;

public class DbConnection {
    public Connection conn;

    private String url = "jdbc:mysql://localhost:3306/StudentInfoManage";
    private String driver = "com.mysql.jdbc.Driver";
    private String user = "root";
    private String password = "123456";


    public DbConnection() {
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void closeConnection(){
        if (conn != null) {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}