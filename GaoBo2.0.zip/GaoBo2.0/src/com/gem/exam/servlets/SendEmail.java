package com.gem.exam.servlets;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Properties;

///////
/*
时间：20190704
功能：密码找回，发送邮件
码农：王自远
 */
@WebServlet(name="SendEmail",urlPatterns = { "/SendEmail"})
public class SendEmail extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");//这两句对于中文乱码很重要了
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        DbConnection Dbconn = new DbConnection();
        PreparedStatement prst = null;
        ResultSet rs = null;
        String username = request.getParameter("username");
        String email = request.getParameter("email");

        try {
            String sql1 = "select * from StudentTable where Sno=? and SEmail=?";
            prst = Dbconn.conn.prepareStatement(sql1);
            prst.setString(1, username);
            prst.setString(2,email);
            rs = prst.executeQuery();
            //out.println("  "+password+"  "+username);
            if (rs.next()) {//存在该学生
                String password = rs.getString(2);
                String content ="您的密码是"+password+",请尽快登录系统并修改密码。";
                String subject = "学生基础信息管理系统密码找回";
                boolean flag = sendMail(email,content,subject);
                if(flag==true) {
                    out.println("    <style>\n" +
                            "        body{\n" +
                            "            margin: 0px auto;\n" +
                            "            background-image: url(\"./resources/images/001.jpg\");\n" +
                            "        }\n" +
                            "    </style>\n");
                    out.println("密码已发送至您的邮箱，系统将在3秒后返回登录页。");
                    out.println("<meta http-equiv=\"refresh\" content=\"3;url=./index.jsp\" />");

                }else {
                    out.println("    <style>\n" +
                            "        body{\n" +
                            "            margin: 0px auto;\n" +
                            "            background-image: url(\"./resources/images/001.jpg\");\n" +
                            "        }\n" +
                            "    </style>\n");
                    out.println("邮件发送失败,请重新找回或联系管理员。系统将在3秒后返回登录页。");
                    out.println("<meta http-equiv=\"refresh\" content=\"3;url=./index.jsp\" />");
                }
                }
            else{
                out.println("    <style>\n" +
                        "        body{\n" +
                        "            margin: 0px auto;\n" +
                        "            background-image: url(\"./resources/images/4.jpg\");\n" +
                        "        }\n" +
                        "    </style>\n");
                out.println("信息出错或填写不完整，请重新检查填写。");
                out.println("<br/>");
                out.print("<a href=\"index.jsp\">返回登录页面</a>");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public  boolean sendMail(String emailTo,String content,String subject) {

        String fromEmail="3061518205@qq.com";//你的QQ邮箱
        String eMailType="smtp.qq.com";
        String eMailAuthPassword="htaexkrgstqhdgjc";//QQ邮箱授权码 开通POP3/SMTP服务 的授权码
        String body = content; //正文内容
        try {
//****************************创建会话***************************************
            Properties props = new Properties();
            props.put("mail.smtp.host",eMailType);//发件人使用发邮件的电子信箱服务器
            props.put("mail.password",eMailAuthPassword);
            props.put("mail.transport.protocol", "smtp");
            props.setProperty("mail.debug", "true");
            props.put("mail.smtp.auth","true"); //这样才能通过验证

            //下面这三句很重要，如果没有加入进去，qq邮箱会验证不成功，一直报503错误
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            props.put("mail.smtp.port", "465");
            props.put("mail.smtp.socketFactory.port", "465");


            //获得默认的session对象
            Session mailSession = Session.getInstance(props);
            mailSession.setDebug(true);

//*****************************构造消息***************************************
            MimeMessage mimeMessage = new MimeMessage(mailSession);

            InternetAddress from=new InternetAddress(fromEmail);
            mimeMessage.setFrom(from);
            InternetAddress to=new InternetAddress(emailTo); //设置收件人地址并规定其类型
            mimeMessage.setRecipient(Message.RecipientType.TO,to);

            mimeMessage.setSentDate(new Date()); 	//设置发信时间
            mimeMessage.setSubject(subject); 		//设置主题
            mimeMessage.setText(body); 				//设置 正文

            //给消息对象设置内容
            BodyPart bodyPart=new MimeBodyPart();					//新建一个存放信件内容的BodyPart对象
            bodyPart.setContent(body, "text/html;charset= GB2312");	//设置 发送邮件内容为HTML类型,并为中文编码

            Multipart multipart=new MimeMultipart();
            multipart.addBodyPart(bodyPart);

            mimeMessage.setContent(multipart);
            mimeMessage.saveChanges();

            //发送消息
            Transport transport=mailSession.getTransport("smtp");
            transport.connect(eMailType,fromEmail,eMailAuthPassword);//发邮件人帐户密码,此外是我的帐户密码，使用时请修改news.properties中的值 。
            transport.sendMessage(mimeMessage,mimeMessage.getAllRecipients());
            transport.close();
//*******************************发送消息********************************
            mimeMessage.writeTo(System.out);//保存消息 并在控制台 显示消息对象中属性信息
           // System.out.println("邮件已成功发送到 " + emailTo);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e);
            return false;
        }

    }
}
