package com.gem.exam.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet(name = "LoginServlet",urlPatterns = {"/LoginServlet"})//主要功能：验证用户是否合法
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");//这两句对于中文乱码很重要了
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        DbConnection Dbconn = new DbConnection();
        PreparedStatement prst = null;
        ResultSet[]  rs = new ResultSet[2];
        //如果某个请求参数有多个值，将使用该方法获取多个值
        //String[] color = request.getParameterValues("color");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        HttpSession session = request.getSession();
        try {
            String sql1 = "select * from StudentTable where Sno=? and Spwd=?";
            prst = Dbconn.conn.prepareStatement(sql1);
            prst.setString(1, username);
            prst.setString(2,password);
            rs[0] = prst.executeQuery();
            String sql4 = "select * from SystemManagerTable where MSno=? and MSpwd=?";
            prst = Dbconn.conn.prepareStatement(sql4);
            prst.setString(1, username);
            prst.setString(2,password);
            rs[1] = prst.executeQuery();
            //out.println("  "+password+"  "+username);
            if (rs[0].next()) {//存在该学生

                session.setAttribute("sno",username);
                session.setAttribute("table","StudentTable");
                session.setAttribute("name",rs[0].getString("Sname"));
                String site = "StudentPage.jsp";
                response.setStatus(response.SC_MOVED_TEMPORARILY);
                response.setHeader("Location", site);
            }else if(rs[1].next()){//存在该管理员
                session.setAttribute("msno",username);
                session.setAttribute("table","SystemManagerTable");
                session.setAttribute("msname",rs[1].getString("Msname"));
                String site = "ManagerPage.jsp";
                response.setStatus(response.SC_MOVED_TEMPORARILY);
                response.setHeader("Location", site);
            }
            else{
                out.println("登陆信息出错或不完整，请重新填写登录。系统将在5秒后返回。");
                out.println("<meta http-equiv=\"refresh\" content=\"5;url=./index.jsp\" />");
                out.println("    <style>\n" +
                        "        body{\n" +
                        "            margin: 0px auto;\n" +
                        "            background-image: url(\"./resources/images/001.jpg\");\n" +
                        "        }\n" +
                        "    </style>\n");
            }
        }catch (Exception e){
            e.printStackTrace();
        }



    }

}
