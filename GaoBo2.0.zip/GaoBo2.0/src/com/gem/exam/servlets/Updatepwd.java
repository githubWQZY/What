package com.gem.exam.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet(name = "Updatepwd",urlPatterns = {"/Updatepwd"})
public class Updatepwd extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");//这两句对于中文乱码很重要了
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        DbConnection Dbconn = new DbConnection();
        PreparedStatement prst = null;
        ResultSet rs = null;
//out.println("来改密码的？");
        String username = request.getParameter("sno");
        String newpassword = request.getParameter("password");
        System.out.println(username+"   "+newpassword+"   "+request.getSession().getAttribute("msno"));
        if(request.getSession().getAttribute("msno")!=null){
            try{
                String sql = "update StudentTable set Spwd = ? where Sno = ? ";
                prst = Dbconn.conn.prepareStatement(sql);
                prst.setString(1, newpassword);
                prst.setString(2, username);
                int num = prst.executeUpdate();
                if(num==1){
                    out.println("密码修改成功，3秒后系统自动返回上一页面。");
                    out.println("<meta http-equiv=\"refresh\" content=\"3;url=ManagerPage.jsp\" />");
                    out.println("    <style>\n" +
                            "        body{\n" +
                            "            margin: 0px auto;\n" +
                            "            background-image: url(\"./resources/images/001.jpg\");\n" +
                            "        }\n" +
                            "    </style>\n");
                }else {
                    out.println("密码修改出错，请检查信息重新尝试修改。3秒后系统自动返回上一页面。");
                    out.println("<meta http-equiv=\"refresh\" content=\"3;url=ManagerPage.jsp\" />");
                    out.println("    <style>\n" +
                            "        body{\n" +
                            "            margin: 0px auto;\n" +
                            "            background-image: url(\"./resources/images/001.jpg\");\n" +
                            "        }\n" +
                            "    </style>\n");
                }
            }catch (SQLException e){
                //e.printStackTrace();

                out.println("密码修改出错，请重新尝试修改。");
                out.println("<meta http-equiv=\"refresh\" content=\"3;url=ManagerPage.jsp\" />");
                out.println("    <style>\n" +
                        "        body{\n" +
                        "            margin: 0px auto;\n" +
                        "            background-image: url(\"./resources/images/001.jpg\");\n" +
                        "        }\n" +
                        "    </style>\n");
            }
        }else{
            out.println("请先登录系统。");
            out.println("<meta http-equiv=\"refresh\" content=\"3;url=index.jsp\" />");
            out.println("    <style>\n" +
                    "        body{\n" +
                    "            margin: 0px auto;\n" +
                    "            background-image: url(\"./resources/images/001.jpg\");\n" +
                    "        }\n" +
                    "    </style>\n");
        }

    }
}
