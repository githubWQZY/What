package com.gem.exam.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet(name="UpdateInfo",urlPatterns = {"/UpdateInfo"})
public class UpdateInfo extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");//这两句对于中文乱码很重要了
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        DbConnection Dbconn = new DbConnection();
        PreparedStatement prst = null;
        ResultSet rs = null;
        //Map<String,Object> map = new HashMap<String,Object>();
        String sno = (String) request.getSession().getAttribute("sno");
        String email = request.getParameter("email");
        String tel = request.getParameter("tel");
        String age = request.getParameter("age");
        String poli = request.getParameter("poli");
        //out.println("要进try"+sno);
        try {
            String sql = "UPDATE StudentTable  set SEmail=?,Stel=?,Spoli=?,Sage=? where Sno=?;";
            prst = Dbconn.conn.prepareStatement(sql);
            prst.setString(1,email );
            prst.setString(2, tel);
            prst.setString(3, poli);
            prst.setString(4, age);
            prst.setString(5, sno);
            int num = prst.executeUpdate();
            if(num==1){

                out.println("资料更新成功,5秒后自动返回。");
                out.println("<meta http-equiv=\"refresh\" content=\"5;url=StudentPage.jsp\" />");
                out.println("    <style>\n" +
                        "        body{\n" +
                        "            margin: 0px auto;\n" +
                        "            background-image: url(\"./resources/images/001.jpg\");\n" +
                        "        }\n" +
                        "    </style>\n");
            }else {
                out.println("资料更新出错，请检查信息重新尝试更新。5秒后系统自动返回上一页面。");
                out.println("<meta http-equiv=\"refresh\" content=\"5;url=SChangeInfo.jsp\" />");
                out.println("    <style>\n" +
                        "        body{\n" +
                        "            margin: 0px auto;\n" +
                        "            background-image: url(\"./resources/images/001.jpg\");\n" +
                        "        }\n" +
                        "    </style>\n");
            }
        } catch (SQLException e) {
                e.printStackTrace();
        }
    }
}
