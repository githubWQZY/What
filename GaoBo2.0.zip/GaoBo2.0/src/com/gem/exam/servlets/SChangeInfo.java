package com.gem.exam.servlets;
/*
时间：20190704
功能：修改学生基础信息
码农：王小白
 */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet(name="SChangeInfo",urlPatterns = {"/SChangeInfo"})
public class SChangeInfo extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");//这两句对于中文乱码很重要了
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        DbConnection Dbconn = new DbConnection();
        PreparedStatement prst = null;
        ResultSet rs = null;
        //Map<String,Object> map = new HashMap<String,Object>();
        String sno = (String) request.getSession().getAttribute("sno");
        //out.println("要进try"+sno);
        try {
            String sql = "select * from StudentTable where Sno=?;";
            prst = Dbconn.conn.prepareStatement(sql);
            prst.setString(1, sno);
            rs = prst.executeQuery();

            //out.println("  "+password+"  "+username);
            //String Sname = rs.getString(2);
            if (rs.next()) {
               /* map.put("Sno", sno);
                map.put("Sname", rs.getString("Sname"));
                map.put("Sclass", rs.getString("Sclass"));
                map.put("Smajor", rs.getString("Smajor"));
                map.put("Sdep", rs.getString("Sdep"));
                map.put("Sage", rs.getString("Sage"));
                map.put("Sgender", rs.getString("Sgender"));
                map.put("Stel", rs.getString("Stel"));
                map.put("SEmail", rs.getString("SEmail"));
                map.put("Sphoto", rs.getString("Sphoto"));
                map.put("Svideo", rs.getString("Svideo"));
                map.put("Sadd", rs.getString("Sadd"));
                map.put("Tno", rs.getString("Tno"));*/
                //out.println(rs.getString(2));
                request.getSession().setAttribute("email",rs.getString("SEmail"));
                request.getSession().setAttribute("tel",rs.getString("Stel"));
                request.getSession().setAttribute("age",rs.getString("Sage"));
                request.getSession().setAttribute("poli",rs.getString("Spoli"));

                String site = "SChangeInfo.jsp";
                response.setStatus(response.SC_MOVED_TEMPORARILY);
                response.setHeader("Location", site);

            }
            }catch(SQLException e){

            }

    }
}
