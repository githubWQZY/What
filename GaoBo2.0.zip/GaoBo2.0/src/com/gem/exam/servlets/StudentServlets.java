package com.gem.exam.servlets;

import DAO.StudentDao;
import DAO.impl.StudentDaoImpl;
import com.alibaba.fastjson.JSONObject;
import model.Student;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "StudentServlet",urlPatterns = {"/StudentServlet"})
public class StudentServlets extends HttpServlet {
    private StudentDao studentDao = new StudentDaoImpl();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");//这两句对于中文乱码很重要了
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        List<Student>  studentsList = new StudentDaoImpl().getStudentList();
        String json = JSONObject.toJSONString(studentsList);
        response.getWriter().write(json!=null?json:"");
        //System.out.println(json);


    }
}
