function showBGColor(){
	//event当前发生的事件
	//event.srcElement 事件源

	if(event && event.srcElement && event.srcElement.tagName=="TD"){
		var td = event.srcElement ;
		var tr = td.parentElement;	//父元素
		tr.style.backgroundColor="indianred";
		var tds = tr.cells;//获取到tr中的所有的单元格
		for(var i = 0 ;i<tds.length ; i++){
			tds[i].style.color = "white";
		}
	}
}

function clearBGColor(){
	if(event && event.srcElement && event.srcElement.tagName=="TD"){
		var td = event.srcElement ;
		var tr = td.parentElement;	//父元素
		tr.style.backgroundColor="Transparent";
		var tds = tr.cells;//获取到tr中的所有的单元格
		for(var i = 0 ;i<tds.length ; i++){
			tds[i].style.color = "darkslategray";
		}
	}
}

function showHand(){
	if(event && event.srcElement && event.srcElement.tagName=="TD"){
		event.srcElement.style.cursor="hand";
	}
}


var xmlHttpRequest ;

//window.onload当页面加载完成时执行....
window.onload = function(){
	var tbl = $("fruit_tbl");
	//获取表格中所有的行
	var trArr = tbl.rows;
	for(var i = 1 ; i<trArr.length-1;i++){
		var tr = trArr[i];
		//绑定事件
		tr.onmouseover=showBGColor;
		tr.onmouseout =clearBGColor;

		//编辑单价
		var td = tr.cells[2] ;
		td.onmouseover = showHand ;	//显示手的形状
	}

	var delImgArr = document.getElementsByName("delImg");
	for(var i = 0 ; i<delImgArr.length ; i++){
		delImgArr[i].onmouseover = showImgHand;
		delImgArr[i].onclick = delStudent ;
	}

	//给添加按钮绑定点击事件
	$("addBtn").onclick = addStudent ;


}

function createXMLHttpRequest(){
	if(window.XMLHttpRequest){//遵循DOM2标准的浏览器
		xmlHttpRequest = new XMLHttpRequest();
	}else if(window.ActiveXObject){//IE浏览器
		try{
			xmlHttpRequest = new ActiveXObject("Msxml2.XMLHTTP");
		}catch(e){
			xmlHttpRequest = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
}

function mysend(){
	//window.location.href="hello02.html";
	createXMLHttpRequest();
	var url = "/StudentServlet";
	xmlHttpRequest.open("GET",url,true);
	xmlHttpRequest.onreadystatechange=mysendCB ;
	xmlHttpRequest.send();
}

function mysendCB(){
	//alert("aaaaaa");
	if(xmlHttpRequest.readyState==4 && xmlHttpRequest.status==200){
		var studentListJSONStr = xmlHttpRequest.responseText;
		var studentJSONList = JSON.parse(studentListJSONStr);
		if(studentJSONList && studentJSONList.length>0){
			for(var i = 0 ; i<studentJSONList.length ; i++){
				var studentJSON = studentJSONList[i];
				
				var studentTbl = $("student_tbl");
				var tr = studentTbl.insertRow(studentTbl.rows.length);
				//alert(studentTbl.rows.length-1);
				var td1 = tr.insertCell();
				td1.innerText = studentJSON.sno;
				var td2 = tr.insertCell();
				td2.innerText = studentJSON.sname;
				var td3 = tr.insertCell();
				td3.innerText = studentJSON.sclass ;
				var td4 = tr.insertCell();
				td4.innerText = studentJSON.smajor ;
				var td5 = tr.insertCell();
				td5.innerText = studentJSON.sdep;
                var td6 = tr.insertCell();
                td6.innerText = studentJSON.sEmail;
                var td7 = tr.insertCell();
                td7.innerText = studentJSON.stel;
                var td8 = tr.insertCell();
                td8.innerText = studentJSON.spwd ;
                var td9 = tr.insertCell();
                td9.innerText = studentJSON.tno ;
                var td10 = tr.insertCell();
                td10.innerText = studentJSON.sadd;
                var td11 = tr.insertCell();
                td11.innerText = studentJSON.sann;
				var td12 = tr.insertCell();
				td12.innerHTML = "<img src='resources/images/del.jpg' class='wh24'/>";

				tr.onmouseover = showBGColor ;
				tr.onmouseout = clearBGColor ;
                td2.onmouseover = showHand ;
                td2.onclick = showAndFill;
				td8.onmouseover = showHand ;
				td8.onclick = editpwd;
				var img = td12.firstChild;
				img.onmouseover = showImgHand ;
				img.onclick = delStudent;
				
			}
			
		}
	}
}

function editpwd(){
    if(event && event.srcElement && event.srcElement.tagName=="TD"){
        var td = event.srcElement ;
        var price = td.innerText;

        td.innerHTML = "<input type='text' size='6'/>";
        var input = td.firstChild;		//firstChild表示第一个子节点
        //<td><input type='text' /></td>
        input.value = price ;
        input.select();
        //给文本框绑定失去焦点事件
        input.onblur=updatePwd;//更新单价
        //在输入框中当键盘摁下的时候需要判断摁的是什么键
        input.onkeydown=inputNum;
    }
}

function inputNum(){
    //0~9 : 48-57
    //backspace:8
    //enter:13
    var kc = event.keyCode ;
    if(!((kc>=48 && kc<=57) || kc==8 || kc==13 ||(kc>=65 && kc<=90) || (kc>=97 && kc<=122))){
        event.returnValue = false ;
    }
    if(kc==13){
        if(event && event.srcElement && event.srcElement.tagName=="INPUT"){
            event.srcElement.blur();
        }
    }
}

function updatePwd(){
    if(event && event.srcElement && event.srcElement.tagName=="INPUT"){
        var input = event.srcElement ;
        var pwd = input.value ;
        var td = input.parentElement ;
        td.innerText = pwd ;
        //更新小计
		var tr = td.parentElement;
		var tds = tr.cells;
		var sno=tds[0].innerHTML;
		window.location.href="/Updatepwd?sno="+sno+"&password="+pwd;
    }
}

 function addStudent(){
    var sno = $("sno").value;
    var sname = $("sname").value;
    var sclass = $("sclass").value;
    var major = $("major").value;
    var dep = $("sdep").value;;
    var semail = $("semail").value;
    var stel = $("stel").value;
    var spwd = $("spwd").value;
    //alert(sno)
     window.location.href="/AddStudent?sno="+sno+"&password="+spwd
	 +"&sname="+sname+"&sclass="+sclass+"&major="+major+"&dep="+dep+"&semail="+semail+"&stel="+stel;
}

function $(id){
	return document.getElementById(id);
}

function showImgHand(){
	event.srcElement.style.cursor='hand';
}

function delStudent(){
	var studentTbl = document.getElementById("student_tbl");
	if(window.confirm("是否确认删除？")){
		var img = event.srcElement ;
		if(img && img.tagName=="IMG"){
			var tr = img.parentElement.parentElement ;
			//studentTbl.deleteRow(tr.rowIndex);
			//alert(tr.cells[0].innerHTML);
			window.location.href="/DeleteStudent?sno="+tr.cells[0].innerHTML;
		}
	}
}


function showAndFill() {
    $("updateBtn").style.display = 'block';
    $("addBtn").style.display = 'none';
    if(event && event.srcElement && event.srcElement.tagName=="TD"){
        var td = event.srcElement;
        var tr = td.parentElement;
        //alert(tr.cells[2].innerHTML);
        var sno = tr.cells[0].innerHTML;

        $("sno").value=sno;
        $("sname").value=tr.cells[1].innerHTML;
        $("sclass").value=tr.cells[2].innerHTML;
        $("major").value=tr.cells[3].innerHTML;
        $("sdep").value=tr.cells[4].innerHTML;;
        $("semail").value=tr.cells[5].innerHTML;
        $("stel").value=tr.cells[6].innerHTML;
        $("spwd").value=tr.cells[7].innerHTML;

    }
}

function updateStudent() {
    var sno = $("sno").value;
    var sname = $("sname").value;
    var sclass = $("sclass").value;
    var major = $("major").value;
    var dep = $("sdep").value;;
    var semail = $("semail").value;
    var stel = $("stel").value;
    var spwd = $("spwd").value;
    //alert(sno)
    window.location.href="/UpdateStudent?sno="+sno+"&password="+spwd
        +"&sname="+sname+"&sclass="+sclass+"&major="+major+"&dep="+dep+"&semail="+semail+"&stel="+stel;
}











